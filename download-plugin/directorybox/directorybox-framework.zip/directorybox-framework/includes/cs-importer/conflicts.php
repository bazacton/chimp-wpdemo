<?php
$conflicted_pages = array(
	"wp_dp_cs" => array(
		"About Us",
		"Home",
	),
);