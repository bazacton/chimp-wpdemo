<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('class_directorybox_maps_disable_backend')) {

    class class_directorybox_maps_disable_backend {

        /**
         * class_directorybox_maps_disable_backend constructor.
         */
        function __construct() {

            add_filter('directorybox_maps_status', array(&$this, 'directorybox_maps_status_callback'), 10);
        }

        /*
         * Disable Maps
         */
        public function directorybox_maps_status_callback($map_status){
            return false;
        }

    }

    new class_directorybox_maps_disable_backend();
}
?>