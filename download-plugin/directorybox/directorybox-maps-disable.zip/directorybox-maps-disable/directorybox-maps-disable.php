<?php
/**
 * Plugin Name: Directorybox Maps Disable
 * Plugin URI: http://themeforest.net/user/Chimpstudio/
 * Description: Directorybox Maps Disable Add on
 * Version: 2.2
 * Author: ChimpStudio
 * Author URI: http://themeforest.net/user/Chimpstudio/
 * @package Directorybox
 * Text Domain: directorybox-maps-disable
 */
// Direct access not allowed.
if (!defined('ABSPATH')) {
    exit;
}
if (!function_exists('pre')) {

    function pre($data, $is_exit = true) {
        echo '<pre>';
        print_r($data);
        echo '</pre>';
        if ($is_exit == true) {
            exit;
        }
    }

}

/**
 * Directorybox_Maps_Disable class.
 */
class Directorybox_Maps_Disable {

    public $admin_notices;

    /**
     * construct function.
     */
    public function __construct() {

        // Define constants
        define('DIRECTORYBOX_MAPS_DISABLE_PLUGIN_VERSION', '1.0');
        define('DIRECTORYBOX_MAPS_DISABLE_PLUGIN_DOMAIN', 'directorybox-maps-disable');
        define('DIRECTORYBOX_MAPS_DISABLE_PLUGIN_URL', WP_PLUGIN_URL . '/directorybox-maps-disable');
        define('DIRECTORYBOX_MAPS_DISABLE_CORE_DIR', WP_PLUGIN_DIR . '/directorybox-maps-disable');
        define('DIRECTORYBOX_MAPS_DISABLE_LANGUAGES_DIR', DIRECTORYBOX_MAPS_DISABLE_CORE_DIR . '/languages');
        define('DIRECTORYBOX_MAPS_DISABLE_INCLUDES_DIR', DIRECTORYBOX_MAPS_DISABLE_CORE_DIR . '/includes');
        $this->admin_notices = array();
        //admin notices
        add_action('admin_notices', array($this, 'maps_disable_notices_callback'));
        if (!$this->check_dependencies()) {
            return false;
        }

        // Initialize Addon
        add_action('init', array($this, 'init'));
    }

    /**
     * Initialize application, load text domain, enqueue scripts, include classes and add actions
     */
    public function init() {
        // Add Plugin textdomain
        $locale = apply_filters('plugin_locale', get_locale(), 'directorybox-maps-disable');
        load_textdomain('directorybox-maps-disable', DIRECTORYBOX_MAPS_DISABLE_LANGUAGES_DIR . '/directorybox-maps-disable' . "-" . $locale . '.mo');
        load_plugin_textdomain('directorybox-maps-disable', false, DIRECTORYBOX_MAPS_DISABLE_LANGUAGES_DIR);

        require_once ( DIRECTORYBOX_MAPS_DISABLE_INCLUDES_DIR . '/class-directorybox-maps-disable-backend.php' );

    }

    /**
     * Check plugin dependencies (Directorybox), nag if missing.
     *
     * @param boolean $disable disable the plugin if true, defaults to false.
     */
    public function check_dependencies($disable = false) {
        $result = true;
        $active_plugins = get_option('active_plugins', array());
        if (is_multisite()) {
            $active_sitewide_plugins = get_site_option('active_sitewide_plugins', array());
            $active_sitewide_plugins = array_keys($active_sitewide_plugins);
            $active_plugins = array_merge($active_plugins, $active_sitewide_plugins);
        }
        $directorybox_is_active = in_array('wp-directorybox-manager/wp-directoryplus-manager.php', $active_plugins);
        if (!$directorybox_is_active) {
            $this->admin_notices[] = '<div class="error">' . __('<em><b>Directorybox Maps Disable</b></em> needs the <b>Directorybox</b> plugin. Please install and activate it.', 'directorybox-maps-disable') . '</div>';
        }
        if (!$directorybox_is_active) {
            if ($disable) {
                include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
                deactivate_plugins(array(__FILE__));
            }
            $result = false;
        }
        return $result;
    }

    public function maps_disable_notices_callback() {
        if (isset($this->admin_notices) && !empty($this->admin_notices)) {
            foreach ($this->admin_notices as $value) {
                echo $value;
            }
        }
    }

}

new Directorybox_Maps_Disable();
