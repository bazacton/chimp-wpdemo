<?php

// Direct access not allowed.
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Disable_Menu_Order_Frontend')) {

    /**
     * Class Disable_Menu_Order_Frontend
     */
    class Disable_Menu_Order_Frontend {

        /**
         * Disable_Menu_Order_Frontend constructor.
         */
        public function __construct() {
            add_filter('foodbakery_restaurant_fields_frontend', array($this, 'foodbakery_restaurant_fields_frontend_callback'), 10, 2);
            add_filter('restaurant_detail_menu_area_cols', array($this, 'restaurant_detail_menu_area_cols_callback'), 11, 2);
            add_filter('restaurant_menu_order_active', array($this, 'restaurant_menu_order_active_callback'), 11, 2);
            add_filter('restaurant_menu_order_active_by_publisher', array($this, 'restaurant_menu_order_active_by_publisher_callback'), 11, 2);
            
        }
        
        /*
         * Frontend Fields in Restaurant Settings
         */

        public function foodbakery_restaurant_fields_frontend_callback($html, $restaurant_id) {
            global $foodbakery_form_fields, $foodbakery_form_fields_frontend;

            $foodbakery_restaurant_menu_ordering = get_post_meta($restaurant_id, 'foodbakery_restaurant_menu_ordering', true);
            
            $html .= '<div class="row">';
            $html .= '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><div class="field-holder"><label>' . esc_html__('Menu Ordering', 'foodbakery-disable-menu-order') . '</label>';
            $html .= $foodbakery_form_fields_frontend->foodbakery_form_select_render(
                    array(
			'id' => 'restaurant_menu_ordering',
			'cust_name' => 'foodbakery_restaurant_menu_ordering',
			'std' => $foodbakery_restaurant_menu_ordering,
			'desc' => '',
			'classes' => 'chosen-select',
			'return' => true,
			'force_std' => true,
			'options' => array(
			    'enabled' => esc_html__('Enable', 'foodbakery-disable-menu-order'),
			    'disabled' => esc_html__('Disable', 'foodbakery-disable-menu-order'),
			),
			'hint_text' => '',
		    )
            );
            $html .= '</div></div>';


            $html .= '</div>';
            return $html;
        }
        
        /*
         * Detail Page Width Full for Menu Area
         */
        public function restaurant_detail_menu_area_cols_callback( $response = '', $foodbakery_restaurant_id){
            $menu_ordering_status = apply_filters('restaurant_menu_order_active', true, $foodbakery_restaurant_id);
            if( $menu_ordering_status != true){
                $response = 'col-lg-10 col-md-10 col-sm-10 col-xs-12';
            }
            return $response;
        }
        
        /*
         * Return if the Menu ordering is disable
         */
        public function restaurant_menu_order_active_callback($menu_ordering_status, $foodbakery_restaurant_id){
            $foodbakery_restaurant_menu_ordering = get_post_meta($foodbakery_restaurant_id, 'foodbakery_restaurant_menu_ordering', true);
            $foodbakery_restaurant_menu_ordering = ( $foodbakery_restaurant_menu_ordering == 'disabled')? false : true;
            return $foodbakery_restaurant_menu_ordering;
        }
        
        /*
         * Return false if the Menu ordering is disable 
         * Check by publisher ID
         */
        public function restaurant_menu_order_active_by_publisher_callback($menu_ordering_status, $publisher_id){
            $foodbakery_restaurant_id   = get_restaurant_id_by_publisher( $publisher_id );
            $menu_ordering_status = apply_filters('restaurant_menu_order_active', $menu_ordering_status, $foodbakery_restaurant_id);
            return $menu_ordering_status;
        }

        

    }

    new Disable_Menu_Order_Frontend();
}
?>