<?php
//======================================================================
// Portfolio html form for page builder start
//======================================================================
if ( ! function_exists( 'cs_pb_portfolio' ) ) {
    function cs_pb_portfolio($die = 0){
        global $cs_node, $post;
        $shortcode_element = '';
        $filter_element = 'filterdrag';
        $shortcode_view = '';
        $output = array();
        $counter = $_POST['counter'];
        $cs_counter = $_POST['counter'];
        if ( isset($_POST['action']) && !isset($_POST['shortcode_element_id']) ) {
            $POSTID = '';
            $shortcode_element_id = '';
        } else {
            $POSTID = $_POST['POSTID'];
            $shortcode_element_id = $_POST['shortcode_element_id'];
            $shortcode_str = stripslashes ($shortcode_element_id);
            $PREFIX = 'cs_portfolio';
            $parseObject     = new ShortcodeParse();
            $output = $parseObject->cs_shortcodes( $output, $shortcode_str , true , $PREFIX );
        }
        $defaults = array('cs_portfolio_section_title'=>'','cs_portfolio_orderby'=>'DESC','cs_portfolio_cat'=>'','cs_portfolio_view'=>'','cs_port_filter'=>'','cs_portfolio_description'=>'yes','cs_portfolio_excerpt'=>'255','cs_portfolio_num_post'=>'10','portfolio_pagination'=>'');
            if(isset($output['0']['atts']))
                $atts = $output['0']['atts'];
            else 
                $atts = array();
            $portfolio_element_size = '50';
            foreach($defaults as $key=>$values){
                if(isset($atts[$key]))
                    $$key = $atts[$key];
                else 
                    $$key =$values;
             }
            $name = 'cs_pb_portfolio';
            $coloumn_class = 'column_'.$portfolio_element_size;
        	if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){
				$shortcode_element = 'shortcode_element_class';
				$shortcode_view = 'cs-pbwp-shortcode';
				$filter_element = 'ajax-drag';
				$coloumn_class = '';
       		}
    ?>
    <div id="<?php echo esc_attr( $name.$cs_counter );?>_del" class="column parentdelete <?php echo esc_attr( $coloumn_class );?> <?php echo esc_attr( $shortcode_view );?>" item="portfolio" data="<?php echo cs_element_size_data_array_index($portfolio_element_size)?>">
      <?php cs_element_setting($name,$cs_counter,$portfolio_element_size);?>
      <div class="cs-wrapp-class-<?php echo intval( $cs_counter )?> <?php echo esc_attr( $shortcode_element );?>" id="<?php echo esc_attr( $name.$cs_counter )?>" data-shortcode-template="[cs_portfolio {{attributes}}]"  style="display: none;">
        <div class="cs-heading-area">
              <h5><?php _e('Edit Portfolio Options', 'cs_frame') ?></h5>
              <a href="javascript:removeoverlay('<?php echo esc_js( $name.$cs_counter );?>','<?php echo esc_js( $filter_element );?>')" class="cs-btnclose"><i class="icon-times"></i></a>
          </div>
        <div class="cs-pbwp-content">
              <div class="cs-wrapp-clone cs-shortcode-wrapp">
                <?php
                 if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){cs_shortcode_element_size();}?>
                    <ul class="form-elements">
                        <li class="to-label"><label><?php _e('Section Title','cs_frame');?></label></li>
                        <li class="to-field">
                            <input  name="cs_portfolio_section_title[]" type="text"  value="<?php echo esc_attr( $cs_portfolio_section_title )?>"   />
                        </li>                  
                     </ul>
                     
                     <ul class="form-elements">
                        <li class="to-label">
                          <label><?php _e('Choose Category','cs_frame');?></label>
                        </li>
                        <li class="to-field">
                          <div class="input-sec">
                            <div class="select-style">
                              <select name="cs_portfolio_cat[]" class="dropdown">
                                <option value="0"><?php _e('-- Select Category --','cs_frame');?></option>
                                <?php cs_show_all_cats('', '', $cs_portfolio_cat, "portfolio-category");?>
                              </select>
                            </div>
                          </div>
                        </li>
                      </ul> 
                      <ul class="form-elements">
                        <li class="to-label">
                          <label><?php _e('Views','cs_frame');?></label>
                        </li>
                        <li class="to-field">
                          <div class="input-sec">
                            <div class="select-style">
                              <select name="cs_portfolio_view[]" class="dropdown">
                                <option value="portfolio-grid" <?php if($cs_portfolio_view == 'portfolio-grid'){echo 'selected="selected"';}?>><?php _e('Portfolio Grid', 'cs_frame') ?></option>
                                <option value="portfolio-plain" <?php if($cs_portfolio_view == 'portfolio-plain'){echo 'selected="selected"';}?>><?php _e('Portfolio Plain', 'cs_frame') ?></option>
                                <option value="portfolio-modren" <?php if($cs_portfolio_view == 'portfolio-modren'){echo 'selected="selected"';}?>><?php _e('Portfolio Modern', 'cs_frame') ?></option>
                                <option value="portfolio-medium" <?php if($cs_portfolio_view == 'portfolio-medium'){echo 'selected="selected"';}?>><?php _e('Portfolio Medium', 'cs_frame') ?></option>
                                <option value="portfolio-masonary" <?php if($cs_portfolio_view == 'portfolio-masonary'){echo 'selected="selected"';}?>><?php _e('Portfolio Masonry', 'cs_frame') ?></option>
                              </select>
                            </div>
                          </div>
                        </li>
                      </ul>
                      <ul class="form-elements">
                        <li class="to-label">
                          <label><?php _e('Filter','cs_frame');?></label>
                        </li>
                        <li class="to-field">
                          <div class="input-sec">
                            <div class="select-style">
                              <select name="cs_port_filter[]" class="dropdown" >
                                <option <?php if($cs_port_filter == "yes")echo "selected";?> value="yes"><?php _e('Yes','cs_frame');?></option>
                                <option <?php if($cs_port_filter == "no")echo "selected";?> value="no"><?php _e('No','cs_frame');?></option>
                              </select>
                            </div>
                          </div>
                        </li>
                      </ul>
                      <ul class="form-elements">
                        <li class="to-label">
                          <label><?php _e('Post Order','cs_frame');?></label>
                        </li>
                        <li class="to-field">
                          <div class="input-sec">
                            <div class="select-style">
                              <select name="cs_portfolio_orderby[]" class="dropdown" >
                                <option <?php if($cs_portfolio_orderby=="ASC")echo "selected";?> value="ASC"><?php _e('Asc','cs_frame');?></option>
                                <option <?php if($cs_portfolio_orderby=="DESC")echo "selected";?> value="DESC"><?php _e('DESC','cs_frame');?></option>
                              </select>
                            </div>
                          </div>
                        </li>
                      </ul>
                      <ul class="form-elements">
                        <li class="to-label">
                          <label><?php _e('Description','cs_frame');?></label>
                        </li>
                        <li class="to-field">
                          <div class="input-sec">
                            <div class="select-style">
                              <select name="cs_portfolio_description[]" class="dropdown" >
                                <option <?php if($cs_portfolio_description=="yes")echo "selected";?> value="yes"><?php _e('Yes','cs_frame');?></option>
                                <option <?php if($cs_portfolio_description=="no")echo "selected";?> value="no"><?php _e('No','cs_frame');?></option>
                              </select>
                            </div>
                          </div>
                        </li>
                      </ul>
                      
                      <ul class="form-elements">
                        <li class="to-label">
                          <label><?php _e('Length of Excerpt','cs_frame');?></label>
                        </li>
                        <li class="to-field">
                          <div class="input-sec">
                            <input type="text" name="cs_portfolio_excerpt[]" class="txtfield" value="<?php echo esc_attr( $cs_portfolio_excerpt );?>" />
                          </div>
                          <div class="left-info">
                            <p><?php _e('Enter number of character for short description text.','cs_frame');?></p>
                          </div>
                        </li>
                      </ul>

                    <ul class="form-elements">
                      <li class="to-label">
                        <label><?php _e('No. of Post Per Page','cs_frame');?></label>
                      </li>
                      <li class="to-field">
                        <div class="input-sec">
                          <input type="text" name="cs_portfolio_num_post[]" class="txtfield" value="<?php echo esc_attr( $cs_portfolio_num_post ); ?>" />
                        </div>
                        <div class="left-info">
                          <p><?php _e('To display all the records, leave this field blank.','cs_frame');?></p>
                        </div>
                      </li>
                    </ul>
                    <ul class="form-elements">
                      <li class="to-label">
                        <label><?php _e('Pagination','cs_frame');?></label>
                      </li>
                      <li class="to-field select-style">
                        <select name="portfolio_pagination[]" class="dropdown">
                          <option <?php if($portfolio_pagination=="Show Pagination")echo "selected";?> ><?php _e('Show Pagination','cs_frame');?></option>
                          <option <?php if($portfolio_pagination=="Single Page")echo "selected";?> ><?php _e('Single Page','cs_frame');?></option>
                        </select>
                      </li>
                    </ul>
                    
                    <?php if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){?>
                    <ul class="form-elements insert-bg">
                      <li class="to-field"> <a class="insert-btn cs-main-btn" onclick="javascript:Shortcode_tab_insert_editor('<?php echo esc_js( str_replace('cs_pb_','',$name) );?>','<?php echo esc_js( $name.$cs_counter )?>','<?php echo esc_js( $filter_element );?>')" ><?php _e('Insert','cs_frame');?></a> </li>
                    </ul>
                    <div id="results-shortocde"></div>
                    <?php } else {?>
                    <ul class="form-elements">
                        <li class="to-label"></li>
                        <li class="to-field">
                        	<input type="hidden" name="cs_orderby[]" value="portfolio" />
                            <input type="button" value="<?php _e('Save','cs_frame');?>" style="margin-right:10px;" onclick="javascript:_removerlay(jQuery(this))" />
                        </li>
                    </ul>
                <?php }?>
              </div>
        </div>
      </div>
    </div>
<?php
        if ( $die <> 1 ) die();
    }
    add_action('wp_ajax_cs_pb_portfolio', 'cs_pb_portfolio');
}