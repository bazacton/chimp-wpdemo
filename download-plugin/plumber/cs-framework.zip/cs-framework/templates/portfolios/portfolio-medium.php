<?php
global $post,$wpdb,$cs_theme_options,$cs_counter_node,$column_attributes,$cs_portfolio_description,$cs_portfolio_excerpt;
extract($wp_query->query_vars);
$width = '470';
$height = '353';
$title_limit = 3;

$query = new WP_Query($args);
$post_count = $query->post_count;
if ($query->have_posts()) {
	$port_counter = 1;
	while ($query->have_posts()) : $query->the_post();
		$cs_port_list_gallery = get_post_meta($post->ID, 'cs_port_list_gallery', true);
		$cs_portfolio_date = get_post_meta($post->ID, 'cs_portfolio_date', true);
		if( $cs_port_list_gallery <> '' ) {
			$cs_port_list_gallery = explode(',', $cs_port_list_gallery);
		
			if( is_array($cs_port_list_gallery) && sizeof($cs_port_list_gallery) > 0 ) {
				$img_url = cs_attachment_image_src($cs_port_list_gallery[0], $width, $height);
				$full_img_url = cs_attachment_image_src($cs_port_list_gallery[0], 0, 0);
			}
		}
		$cs_postObject = get_post_meta($post->ID, "cs_full_data", true);
		
		$port_cats = get_the_terms( $post->ID, 'portfolio-category' );
		
		$port_cats = get_the_terms( $post->ID, 'portfolio-category' );
		$cat_slug = '';
		foreach( $port_cats as $cat ) {
			$cat_slug .= ' '.$cat->slug;
		}
		?> 
		<li class="portfolio-item <?php echo cs_allow_special_char($cat_slug); ?>">
			<div class="item-main">
				<article class="col-md-12">
                    <div class="cs-portfolio-holder">
                        <?php if( isset($img_url) && $img_url <> '' ) { ?>
                        <div class="cs-media">
                            <figure>
                                <a href="<?php esc_url(the_permalink()); ?>"><img alt="<?php echo cs_get_post_img_title($post->ID); ?>" src="<?php echo esc_url($img_url); ?>"></a>
                                <figcaption><a href="<?php esc_url(the_permalink()); ?>"><i class="icon-angle-right"></i></a></figcaption>
                            </figure>
                        </div>
                        <?php } ?>
                        <section class="cs-text">
                            <span class="count"><?php echo absint($port_counter); ?>/<?php echo absint($post_count); ?></span>
                            <h1><a href="<?php esc_url(the_permalink()); ?>"><?php echo wp_trim_words(get_the_title($post->ID), $title_limit, '...'); ?></a></h1>
                            <ul class="cs-options">
                                <?php
								$categories_list = get_the_term_list(get_the_id(), 'portfolio-category', '<li>', ', ', '</li>');
								if ($categories_list) {
									echo cs_allow_special_char( $categories_list );
								}
								?>
                                <li><i class="icon-clock-o"></i><?php echo date_i18n( get_option('date_format'), strtotime($cs_portfolio_date) ); ?></li>
                            </ul>
                            <?php if ($cs_portfolio_description == 'yes') { ?><p> <?php echo cs_get_the_excerpt($cs_portfolio_excerpt, 'true', ''); ?></p><?php } ?> 
                            <?php
							if( is_array($cs_port_list_gallery) && sizeof($cs_port_list_gallery) > 1 ) {
							?>
                            <ul class="cs-gallery-view">
                            	<?php
								$gal_counter = 0;
								foreach( $cs_port_list_gallery as $gal_list ) {
								
								$gal_url = cs_attachment_image_src($gal_list, 120, 90);
								?>
                                <li>
                                    <figure><a><img src="<?php echo esc_url($gal_url); ?>" alt="<?php echo cs_get_post_img_title($post->ID); ?>"></a></figure>
                                </li>
                                <?php
								$gal_counter++;
								if( $gal_counter > 4 ) break; 
								}
								?>
                            </ul>
                            <?php
							}
							?>
                        </section>
                    </div>
                </article>
			</div>
		</li>
		<?php
		$port_counter++;
	endwhile;
} else {
	_e('No Portfolio found.', 'cs_frame');
}
