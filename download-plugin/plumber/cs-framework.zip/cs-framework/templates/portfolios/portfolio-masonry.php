<?php
global $post,$wpdb,$cs_theme_options,$cs_counter_node,$column_attributes,$cs_portfolio_description,$cs_portfolio_excerpt;
extract($wp_query->query_vars);
$width = '314';
$height = '236';
$title_limit = 3;

$query = new WP_Query($args);
$post_count = $query->post_count;
if ($query->have_posts()) {
	$postCounter = 0;
	while ($query->have_posts()) : $query->the_post();
		$cs_port_list_gallery = get_post_meta($post->ID, 'cs_port_list_gallery', true);
		if( $cs_port_list_gallery <> '' ) {
			$cs_port_list_gallery = explode(',', $cs_port_list_gallery);
		
			if( is_array($cs_port_list_gallery) && sizeof($cs_port_list_gallery) > 0 ) {
				$img_url = cs_attachment_image_src($cs_port_list_gallery[0], 0, 0);
				$full_img_url = cs_attachment_image_src($cs_port_list_gallery[0], 0, 0);
			}
		}
		$cs_postObject = get_post_meta($post->ID, "cs_full_data", true);
		
		$port_cats = get_the_terms( $post->ID, 'portfolio-category' );
		$cat_slug = '';
		foreach( $port_cats as $cat ) {
			$cat_slug .= ' '.$cat->slug;
		}
		?> 
		<li class="portfolio-item <?php echo cs_allow_special_char($cat_slug); ?> col-md-4">
			<div class="item-main">
                <article>
                    <div class="cs-portfolio-holder">
                        <?php if( isset($img_url) && $img_url <> '' ) { ?>
                        <div class="cs-media">
                            <figure><a href="<?php esc_url(the_permalink()); ?>"><img src="<?php echo esc_url($img_url); ?>" alt="<?php echo cs_get_post_img_title($post->ID); ?>"></a>
                                <figcaption>
                                    <a href="<?php echo esc_url($full_img_url); ?>" rel="prettyPhoto"><i class="icon-search3"></i></a>
                                </figcaption>
                            </figure>
                        </div>
                        <?php } ?>
                        <section class="cs-text">
                            <span class="cs-icons-style"><i class="icon-file-text-o"></i></span>
                            <h4><a href="<?php esc_url(the_permalink()); ?>"><?php echo wp_trim_words(get_the_title($post->ID), $title_limit, '...'); ?></a></h4>
                        </section>
                    </div>
                </article>
            </div>
		</li>
		<?php
	endwhile;
} else {
	_e('No Portfolio found.', 'cs_frame');
}
