<?php
if (!function_exists('cs_portfolio_shortcode')) {
    function cs_portfolio_shortcode( $atts ) {
		global $post,$wp_query,$wpdb,$cs_theme_options,$cs_counter_node,$column_attributes,$cs_port_filter,$cs_portfolio_description,$cs_portfolio_excerpt;
		$defaults = array('cs_portfolio_section_title'=>'','cs_portfolio_orderby'=>'DESC','cs_portfolio_cat'=>'','cs_portfolio_view'=>'','cs_port_filter'=>'','cs_portfolio_description'=>'yes','cs_portfolio_excerpt'=>'255','cs_portfolio_num_post'=>'10','portfolio_pagination'=>'');
        extract( shortcode_atts( $defaults, $atts ) );
        
		$cs_dataObject = get_post_meta($post->ID,'cs_full_data');
		
		// Check Section or page layout
        $cs_sidebarLayout  = '';
        $section_cs_layout = '';
        $pageSidebar 	   = false;        
        $box_col_class 	   = 'col-md-3';
        
		if(isset($cs_dataObject['cs_page_layout'])) $cs_sidebarLayout = $cs_dataObject['cs_page_layout'];
        
		if(isset($column_attributes->cs_layout)){
            $section_cs_layout = $column_attributes->cs_layout;
			if ( $section_cs_layout == 'left' || $section_cs_layout == 'right' ) {
				$pageSidebar = true;
			}
        }
        
        if ( $cs_sidebarLayout == 'left' || $cs_sidebarLayout == 'right') {
            $pageSidebar = true;
        }        
        
		if($pageSidebar == true) {
            $box_col_class = 'col-md-4';
        }
        
		// Check Section or page layout ends
        
        if ((isset($cs_dataObject['cs_page_layout']) && $cs_dataObject['cs_page_layout'] <> '' and $cs_dataObject['cs_page_layout'] <> "none") || $pageSidebar == true){           
                $cs_portfolio_grid_layout = 'col-md-4';
        }else{
                $cs_portfolio_grid_layout = 'col-md-3';    
        }        
        
		$CustomId    = '';
        
		if ( isset( $cs_portfolio_class ) && $cs_portfolio_class ) {
            $CustomId    = 'id="'.$cs_portfolio_class.'"';
        }        
        
        $cs_counter_node++;
        ob_start();        
             
        if (empty($_GET['page_id_all'])) $_GET['page_id_all'] = 1;
        $cs_portfolio_num_post    = $cs_portfolio_num_post ? $cs_portfolio_num_post : '-1';        
        $args = array('posts_per_page' => "-1", 'post_type' => 'portfolios', 'order' => $cs_portfolio_orderby, 'orderby' => 'ID', 'post_status' => 'publish');
        
		if(isset($cs_portfolio_cat) && $cs_portfolio_cat <> '' &&  $cs_portfolio_cat <> '0'){
            $port_category_array = array('portfolio-category' => "$cs_portfolio_cat");
            $args = array_merge($args, $port_category_array);
        }
        
		$query = new WP_Query( $args );
        $count_post = $query->post_count;        
        $cs_portfolio_num_post    = $cs_portfolio_num_post ? $cs_portfolio_num_post : '-1';
        $args = array('posts_per_page' => "$cs_portfolio_num_post", 'post_type' => 'portfolios', 'paged' => $_GET['page_id_all'], 'order' => $cs_portfolio_orderby, 'orderby' => 'ID', 'post_status' => 'publish');
		if(isset($cs_portfolio_cat) && $cs_portfolio_cat <> '' &&  $cs_portfolio_cat <> '0'){
            $port_category_array = array('portfolio-category' => "$cs_portfolio_cat");
            $args = array_merge($args, $port_category_array);
        }
        
        $outerDivStart		= '
		<div id="col-md-12">
		<div id="portfolio-section">
		<div class="wrap-pad first">';
		
        $outerDivEnd		= '
		</div>
		</div>
		</div>';
        $section_title		= '';
		
		$cs_mas_class = '';
		$randomId = rand(12233443, 94354344);
		if ( $cs_portfolio_view == 'portfolio-masonary' ) {
			
			$cs_mas_class = ' mas-isotope-'.$randomId;
			cs_isotope_enqueue();
			echo '<script>
					 jQuery(document).ready(function($) {
						var container = jQuery(".mas-isotope-'.$randomId.' ul").imagesLoaded(function() {
							container.isotope()
						});
						jQuery(window).resize(function() {
							setTimeout(function() {
								jQuery(".mas-isotope-'.$randomId.' ul").isotope()
							}, 600)
						});
					 });    
				  </script>';          
		}
        
        if(isset($cs_portfolio_section_title) && trim($cs_portfolio_section_title) <> ''){
            $section_title = '<div class="main-title"><div class="cs-section-title"><h2>'.$cs_portfolio_section_title.'</h2></div></div>';
        }
		
        echo cs_allow_special_char($outerDivStart);
        echo cs_allow_special_char($section_title);	
        
		set_query_var( 'args', $args );
		
		cs_port_filters( $cs_portfolio_cat );
		cs_enqueue_gallery_style_script();
		echo cs_allow_special_char('<div class="cs-portfolio cs-'.esc_attr($cs_portfolio_view).' gallery '.$cs_mas_class.'">');
		echo cs_allow_special_char('<ul class="portfolio-items light-box">');
		if ( $cs_portfolio_view == 'portfolio-grid' ) {
			include('portfolio-grid.php');
		} else if ( $cs_portfolio_view == 'portfolio-plain' ) {
			include('portfolio-plain.php');
		} else if ( $cs_portfolio_view == 'portfolio-modren' ) {
			include('portfolio-modren.php');
		} else if ( $cs_portfolio_view == 'portfolio-masonary' ) {
			include('portfolio-masonry.php');
		} else if ( $cs_portfolio_view == 'portfolio-medium' ) {
			include('portfolio-medium.php');
		} else {
			include('portfolio-grid.php');
		}
		echo cs_allow_special_char('</ul>');
		echo cs_allow_special_char('</div>');
		echo cs_allow_special_char($outerDivEnd);      
		//==Pagination Start
		if ( $portfolio_pagination == "Show Pagination" && $count_post > $cs_portfolio_num_post && $cs_portfolio_num_post > 0 && $cs_port_filter != 'yes' ) {
			$qrystr = '';
			if ( isset($_GET['page_id']) ) $qrystr .= "&amp;page_id=".$_GET['page_id'];               
			echo cs_pagination($count_post, $cs_portfolio_num_post,$qrystr,'Show Pagination');
		}
		//==Pagination End    
           
        wp_reset_postdata();    
            
        $post_data = ob_get_clean();
        return $post_data;
     }
    add_shortcode( 'cs_portfolio', 'cs_portfolio_shortcode' );
}

if (!function_exists('cs_port_filters')) {
    function cs_port_filters( $cs_filter_category ) {
		
		global $wpdb, $cs_port_filter;
		$cs_html = '';
		
		if( $cs_port_filter == 'yes' ) {
			
			cs_filter_enqueue();
			
			$row_cat = $wpdb->get_row($wpdb->prepare("SELECT * from $wpdb->terms WHERE slug = %s", $cs_filter_category ));
			if( isset($cs_filter_category) && ($cs_filter_category <> "" && $cs_filter_category <> "0") && isset( $row_cat->term_id ) ) {	
				$categories = get_categories( array('child_of' => "$row_cat->term_id", 'taxonomy' => 'portfolio-category', 'hide_empty' => 0));
			} else {
				$categories = get_categories( array('taxonomy' => 'portfolio-category', 'hide_empty' => 0) );
			}
			$cs_html  .='
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" >
                                <ul class="cs-filtter portfolio-filter">
                                    <li><a data-filter="*" href="#" >'.__('List All', 'cs_frame').'</a></li>';
										foreach ($categories as $category) {
											$cs_html .= '<li><a data-filter=".'.$category->slug.'" href="#">'.($category->cat_name).'</a></li>';
										}
									$cs_html .= '
                                </ul>
                            </div>';
		}
		echo force_balance_tags ( $cs_html );
	}
}

if (!function_exists('cs_port_full_gallery')) {
    function cs_port_full_gallery( $cs_port_gallery, $cs_port_list_gallery ) {
		global $post;
		$cs_uniq = rand( 23423, 32433 );
		if( $cs_port_gallery == 'on' && $cs_port_list_gallery <> '' ) {
			$cs_port_list_gallery = explode(',', $cs_port_list_gallery);
		
			if( is_array($cs_port_list_gallery) && sizeof($cs_port_list_gallery) > 0 ) {
				
				cs_enqueue_flexslider_script();
				?>
				<script type="text/javascript">
				var $ = jQuery;
				$(window).load(function() {
					var target_flexslider = $('#slider-<?php echo absint( $cs_uniq ) ?>');
					
					$('#carousel').flexslider({
						animation: "slide",
						controlNav: false,
						animationLoop: false,
						slideshow: false,
						itemWidth: 118,
						itemMargin: 10,
						asNavFor: '#slider-<?php echo absint( $cs_uniq ) ?>',	

					});
						
					target_flexslider.flexslider({
						animation: "slide",
						controlNav: false,
						animationLoop: false,
						slideshow: false,
						sync: "#carousel",
						start: function(slider) {
						   target_flexslider.parents('.cs-gallery').removeClass('cs-loading');
						   target_flexslider.find('.loader').remove();
						}	
					});
				});
				</script>
				<div class="page-section">
					<div class="cs-gallery cs-loading">
                    	<div class="loader"><?php _e('Loading', 'cs_frame') ?>...</div>
						<div id="slider-<?php echo absint( $cs_uniq ) ?>">
						  <ul class="slides">
							<?php
							foreach( $cs_port_list_gallery as $gal_list ) {
							$img_url = cs_attachment_image_src($gal_list, 960, 540);
							?>
							<li>
							  <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo cs_get_post_img_title($post->ID); ?>" />
							</li>
							<?php
							}
							?>
						  </ul>
						</div>
						<div class="container">
						  <div id="carousel">
							<ul class="slides">
							  <?php
							  foreach( $cs_port_list_gallery as $gal_list ) {
							  $thumb_url = cs_attachment_image_src($gal_list, 120, 90);
							  ?>
							  <li>
								<img src="<?php echo esc_url($thumb_url); ?>" alt="<?php echo cs_get_post_img_title($post->ID); ?>" />
							  </li>
							  <?php
							  }
							  ?>
							</ul>
						  </div>
						</div>
					</div>
				</div>
				<?php
			}
		}
	}
}

if (!function_exists('cs_port_side_detail')) {
    function cs_port_side_detail( $cs_port_detail = array() ) {
		
		extract( $cs_port_detail );
		
		$cs_head_class = 'cs-detail-head';
		if( isset($cs_widget_title) && $cs_widget_title == true ) $cs_head_class = 'widget-section-title';
		?>
        <div class="<?php echo sanitize_html_class($cs_head_class) ?>">
            <h5><?php _e('Project Detail', 'cs_frame') ?></h5>
        </div>
        <ul class="cs-detail-list">
            <li>
                <span class="title"><?php _e('Project Date', 'cs_frame') ?></span>
                <time datetime="2008-02-14"><?php echo date_i18n( get_option('date_format'), strtotime($cs_portfolio_date) ); ?></time>
            </li>
            <?php if( $cs_portfolio_client <> '' ) { ?>
            <li>
                <span class="title"><?php _e('Client', 'cs_frame') ?></span>
                <span class="desc"><?php echo esc_attr( $cs_portfolio_client ); ?></span>
            </li>
            <?php
            }
            $categories_list = get_the_term_list(get_the_id(), 'portfolio-category', '<li>', '</li><li>', '</li>');
            if ($categories_list) {
            ?>
            <li>
                <span class="title"><?php _e('Categories', 'cs_frame') ?></span>
                <ul class="cat-list">
                    <?php printf('%1$s', $categories_list); ?>
                </ul>
            </li>
            <?php
            }
            if( is_array($cs_portfolio_team) && sizeof($cs_portfolio_team) > 0 ) {
            ?>
            <li>
                <span class="title"><?php _e('Project team', 'cs_frame') ?></span>
                <?php foreach( $cs_portfolio_team as $cs_team ) { ?>
                    <span class="desc"><?php echo get_the_title($cs_team) ?></span>
                <?php } ?>
            </li>
            <?php
            }
            if( $cs_portfolio_location <> '' ) {
            ?>
            <li>
                <span class="title"><?php _e('Location', 'cs_frame') ?></span>
                <span class="desc">
                    <?php echo cs_allow_special_char(nl2br($cs_portfolio_location)); ?>
                </span>
            </li>
            <?php
            }
            if( $cs_post_social_sharing == 'on' ) {
            ?>
            <li class="cs-share">
                <?php cs_portfolio_share( __('Share Project', 'cs_frame') ); ?>
            </li>
            <?php
            }
            ?>
        </ul>
        <?php
	}
}
if (!function_exists('cs_port_specs')) {
    function cs_port_specs( $cs_port_specs = array() ) {
		
		extract( $cs_port_specs );
		
		if( $cs_portfolio_specs == 'on' ) { 
			if( $cs_portfolio_specs_title <> '' ) { 
			?>
			<div class="cs-heading">
				<h5><?php echo esc_attr($cs_portfolio_specs_title); ?></h5>
			</div>
			<?php
			}
			if( $cs_portfolio_specs_desc <> '' ) {
			$cs_portfolio_specs_desc = nl2br($cs_portfolio_specs_desc);
			$cs_portfolio_specs_desc = str_replace('<br />', '</p><p>', $cs_portfolio_specs_desc);
			
			echo '<p>'.cs_allow_special_char($cs_portfolio_specs_desc).'</p>';
			}
			
			if( $cs_portfolio_specs_list <> '' ) {
			?>
			<ul class="spec-list">
				<li>
				<?php
				$cs_portfolio_specs_list = nl2br($cs_portfolio_specs_list);
				$cs_portfolio_specs_list = str_replace('<br />', '</li><li>', $cs_portfolio_specs_list);
				echo cs_allow_special_char($cs_portfolio_specs_list);
				?>
				</li>
			</ul>
		<?php
			}
		}
	}
}

if (!function_exists('cs_port_others')) {
    function cs_port_others( $cs_col = false, $cs_limit = '-1' ) {
		
		global $post;
		
		$title_limit = 3;
		$custom_taxterms = '';
		$width  = 314;
		$height = 236;
		$custom_taxterms = wp_get_object_terms( $post->ID, array('portfolio-category'), array('fields' => 'ids') );
		$args = array(
					'post_type' => 'portfolios',
					'post_status' => 'publish',
					'posts_per_page' => $cs_limit,
					'orderby' => 'DESC',
					'tax_query' => array(
					'relation' => 'OR',
						array(
						  'taxonomy' => 'portfolio-category',
						  'field' => 'id',
						  'terms' => $custom_taxterms
						)
					),
					'post__not_in' => array ($post->ID),
				);
		$custom_query = new WP_Query($args);
		while ($custom_query->have_posts()) : $custom_query->the_post();
		$cs_port_list_gallery = get_post_meta($post->ID, 'cs_port_list_gallery', true);
		if( $cs_port_list_gallery <> '' ) {
			$cs_port_list_gallery = explode(',', $cs_port_list_gallery);
		
			if( is_array($cs_port_list_gallery) && sizeof($cs_port_list_gallery) > 0 ) {
				$img_url = cs_attachment_image_src($cs_port_list_gallery[0], $width, $height);
				$full_img_url = cs_attachment_image_src($cs_port_list_gallery[0], 0, 0);
			}
		}
		
		$cs_col_class = '';
		if( $cs_col == true ) $cs_col_class = ' class="col-md-4"';
		?>
		<article<?php echo cs_allow_special_char($cs_col_class) ?>>
			<div class="cs-portfolio-holder">
				<?php if( isset($img_url) && $img_url <> '' ) { ?>
				<div class="cs-media">
					<figure><a href="<?php esc_url(the_permalink()); ?>"><img alt="<?php echo cs_get_post_img_title($post->ID); ?>" src="<?php echo esc_url($img_url); ?>" /></a>
						<figcaption>
							<div class="cs-icon-area">
								<a href="<?php echo esc_url($full_img_url); ?>" rel="prettyPhoto" ><i class="icon-search3"></i></a>
								<a href="<?php esc_url(the_permalink()); ?>"><i class="icon-file-text-o"></i></a>
							</div>
						</figcaption>
					</figure>
				</div>
				<?php } ?>
				<section class="cs-text">
					<h4><a href="<?php esc_url(the_permalink()); ?>"><?php echo wp_trim_words(get_the_title($post->ID), $title_limit, '...'); ?></a></h4>
					<?php
					$categories_list = get_the_term_list(get_the_id(), 'portfolio-category', '<span>', ', ', '</span>');
					if ($categories_list) {
						
						echo cs_allow_special_char( $categories_list );
					}
					?>
				</section>
			</div>
		</article>
		<?php
		endwhile;
		wp_reset_query();
	}
}

if (!function_exists('cs_port_others_side')) {
    function cs_port_others_side( $cs_limit = '-1' ) {
		
		global $post;
		
		$title_limit = 3;
		$custom_taxterms = '';
		$width  = 314;
		$height = 236;
		$custom_taxterms = wp_get_object_terms( $post->ID, array('portfolio-category'), array('fields' => 'ids') );
		$args = array(
					'post_type' => 'portfolios',
					'post_status' => 'publish',
					'posts_per_page' => $cs_limit,
					'orderby' => 'DESC',
					'tax_query' => array(
					'relation' => 'OR',
						array(
						  'taxonomy' => 'portfolio-category',
						  'field' => 'id',
						  'terms' => $custom_taxterms
						)
					),
					'post__not_in' => array ($post->ID),
				);
		$custom_query = new WP_Query($args);
		while ($custom_query->have_posts()) : $custom_query->the_post();
		$cs_port_list_gallery = get_post_meta($post->ID, 'cs_port_list_gallery', true);
		if( $cs_port_list_gallery <> '' ) {
			$cs_port_list_gallery = explode(',', $cs_port_list_gallery);
		
			if( is_array($cs_port_list_gallery) && sizeof($cs_port_list_gallery) > 0 ) {
				$img_url = cs_attachment_image_src($cs_port_list_gallery[0], $width, $height);
				$full_img_url = cs_attachment_image_src($cs_port_list_gallery[0], 0, 0);
			}
		}
		
		?>
		<li>
        	<?php if( isset($img_url) && $img_url <> '' ) { ?>
            <figure>
                <a href="<?php esc_url(the_permalink()); ?>"><img alt="<?php echo cs_get_post_img_title($post->ID); ?>" src="<?php echo esc_url($img_url); ?>" /></a>
            </figure>
            <?php } ?>
            <div class="cs-text">
                <h5><a href="<?php esc_url(the_permalink()); ?>"><?php echo wp_trim_words(get_the_title($post->ID), $title_limit, '...'); ?></a></h5>
				<?php
                $categories_list = get_the_term_list(get_the_id(), 'portfolio-category', '<span>', ', ', '</span>');
                if ($categories_list) {
                    
                    echo cs_allow_special_char( $categories_list );
                }
                ?>
            </div>
        </li>
		<?php
		endwhile;
		wp_reset_query();
	}
}

if (!function_exists('cs_port_banner')) {
    function cs_port_banner( $cs_banner, $cs_type ) {
		
		global $cs_theme_options;
		
		if( $cs_banner <> '' && $cs_banner >= 0 ) { 
			if( isset($cs_theme_options['banner_field_code_no'][$cs_banner]) && $cs_theme_options['banner_field_code_no'][$cs_banner] <> '' ) {
			
			$cs_banner_code = $cs_theme_options['banner_field_code_no'][$cs_banner];
			
			$cs_class = 'add-banner col-md-12';
			
			if( $cs_type == 'side' ) $cs_class = 'add-banner2';
			?>
			<div class="<?php echo cs_allow_special_char( $cs_class ); ?>">
				<figure>
					<?php echo do_shortcode('[cs_ads id="'.$cs_banner_code.'"]'); ?>
				</figure>
			</div>
			<?php
			}
		}
	}
}
