<?php
/**
 * The template for displaying single post
 */
	global $post, $cs_theme_options;
	$cs_uniq = rand(11111111, 99999999);
	$cs_postObject 			= get_post_meta($post->ID, 'cs_full_data', true);
	get_header();
		
	$cs_portfolio_style 			= get_post_meta($post->ID, 'cs_portfolio_style', true);
	$cs_post_social_sharing 		= get_post_meta($post->ID, 'cs_post_social_sharing', true);
	$post_pagination_show 			= get_post_meta($post->ID, 'cs_post_pagination_show', true);
	
	$cs_portfolio_specs				= get_post_meta($post->ID, 'cs_portfolio_specs', true);
	$cs_portfolio_specs_title		= get_post_meta($post->ID, 'cs_portfolio_specs_title', true);
	$cs_portfolio_specs_desc		= get_post_meta($post->ID, 'cs_portfolio_specs_desc', true);
	$cs_portfolio_specs_list		= get_post_meta($post->ID, 'cs_portfolio_specs_list', true);
	
	$cs_portfolio_date				= get_post_meta($post->ID, 'cs_portfolio_date', true);
	$cs_portfolio_client			= get_post_meta($post->ID, 'cs_portfolio_client', true);
	
	$cs_portfolio_team				= get_post_meta($post->ID, 'cs_portfolio_team', true);
	$cs_portfolio_location			= get_post_meta($post->ID, 'cs_portfolio_location', true);
	
	$cs_portfolio_other				= get_post_meta($post->ID, 'cs_portfolio_other', true);
	$cs_portfolio_other_title		= get_post_meta($post->ID, 'cs_portfolio_other_title', true);
	$cs_portfolio_proj_bg			= get_post_meta($post->ID, 'cs_portfolio_proj_bg', true);
	
	$cs_portfolio_side_baner		= get_post_meta($post->ID, 'cs_portfolio_side_baner', true);
	$cs_portfolio_btm_baner			= get_post_meta($post->ID, 'cs_portfolio_btm_baner', true);
	
	$cs_port_gallery				= get_post_meta($post->ID, 'cs_port_gallery', true);
	$cs_port_gallery_title			= get_post_meta($post->ID, 'cs_port_gallery_title', true);
	$cs_port_list_gallery			= get_post_meta($post->ID, 'cs_port_list_gallery', true);
	
	$width  = 960;
	$height = 540;
	$image_url = cs_get_post_img_src($post->ID, 960, 540);
	$cs_section_bg = $image_url <> '' ? esc_url( $image_url ) : '';
	cs_enqueue_gallery_style_script();
	if( have_posts() ) :
		while ( have_posts() ) : the_post();
			
			if( $cs_portfolio_style == 'style-1' ) {
				cs_port_full_gallery( $cs_port_gallery, $cs_port_list_gallery );
			}
			?>
            
			<div class="page-section">
				<div class="container">
					<div class="row">
						<div class="section-fullwidth">
                            <div class="cs-project-block">
                            	<?php
								if( $cs_portfolio_style == 'style-1' ) {
								?>
                                <div class="cs-project-details cs-details2">
								<?php
								}

									if( $cs_portfolio_style == 'style-2' ) {
										if( $cs_port_list_gallery <> '' ) {
											$cs_port_list_gallery = explode(',', $cs_port_list_gallery);
										
											if( is_array($cs_port_list_gallery) && sizeof($cs_port_list_gallery) > 0 ) {
												$img_url = cs_attachment_image_src($cs_port_list_gallery[0], $width, $height);
											}
										}
										if( isset($img_url) && $img_url <> '' ) {
											?>
											<figure class="col-md-12" style="margin-bottom:28px;">
												<img src="<?php echo esc_url($img_url); ?>" alt="<?php echo cs_get_post_img_title($post->ID); ?>">
											</figure>
											<?php
										}
									}
									if( $cs_portfolio_style == 'style-1' ) {
									?>
                                    <div class="col-md-9">
                                        <div class="cs-heading">
                                            <h1><?php the_title(); ?></h1>
                                        </div>
                                        <div class="cs-editor-text">
											<?php the_content(); ?>
                                        </div>
                                        <?php 
										$cs_portf_specs = array(
											'cs_portfolio_specs'			=> $cs_portfolio_specs,
											'cs_portfolio_specs_title'		=> $cs_portfolio_specs_title,
											'cs_portfolio_specs_desc'		=> $cs_portfolio_specs_desc,
											'cs_portfolio_specs_list'		=> $cs_portfolio_specs_list,
										);
										cs_port_specs( $cs_portf_specs );
										
										// Pagination
										cs_portfolios_next_prev();
										?>
                                        
                                    </div>
                                    <?php
									echo '<div class="col-md-3">';
										$cs_side_detail = array(
											'cs_portfolio_date'			=> $cs_portfolio_date,
											'cs_portfolio_client'		=> $cs_portfolio_client,
											'cs_portfolio_team'			=> $cs_portfolio_team,
											'cs_portfolio_location'		=> $cs_portfolio_location,
											'cs_post_social_sharing'	=> $cs_post_social_sharing,
										);
										cs_port_side_detail( $cs_side_detail );
									echo '</div>';
									
									cs_port_banner( $cs_portfolio_btm_baner, 'bottom' );
									}
									else if( $cs_portfolio_style == 'style-2' ) {
										?>
                                        <div class="cs-project-details">
                                        	<div class="col-md-3">
												<?php
                                                $cs_side_detail = array(
                                                    'cs_portfolio_date'			=> $cs_portfolio_date,
                                                    'cs_portfolio_client'		=> $cs_portfolio_client,
                                                    'cs_portfolio_team'			=> $cs_portfolio_team,
                                                    'cs_portfolio_location'		=> $cs_portfolio_location,
                                                    'cs_post_social_sharing'	=> $cs_post_social_sharing,
                                                );
                                                cs_port_side_detail( $cs_side_detail );
                                                cs_port_banner( $cs_portfolio_side_baner, 'side' );
                                                ?>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="cs-heading">
                                                    <h5><?php _e('Project Description', 'cs_frame') ?></h5>
                                                </div>
                                                <div class="cs-editor-text">
													<?php the_content(); ?>
                                                </div>
                                                <?php 
												$cs_portf_specs = array(
													'cs_portfolio_specs'			=> $cs_portfolio_specs,
													'cs_portfolio_specs_title'		=> $cs_portfolio_specs_title,
													'cs_portfolio_specs_desc'		=> $cs_portfolio_specs_desc,
													'cs_portfolio_specs_list'		=> $cs_portfolio_specs_list,
												);
												cs_port_specs( $cs_portf_specs );
												
												if( $cs_port_gallery == 'on' && $cs_port_list_gallery <> '' ) {
												
												if( $cs_port_gallery_title <> '' ) {
												?>
												<div class="cs-heading">
													<h5><?php echo esc_attr($cs_port_gallery_title); ?></h5>
												</div>
                                                <?php
												}
												
												if( ! is_array($cs_port_list_gallery) ) {
													$cs_port_list_gallery = explode(',', $cs_port_list_gallery);
												}
		
												if( is_array($cs_port_list_gallery) && sizeof($cs_port_list_gallery) > 0 ) {
													?>
													<div class="cs-project-gallery light-box">
														<?php
														foreach( $cs_port_list_gallery as $gal_list ) {
														
														$img_url = cs_attachment_image_src($gal_list, 314, 236);
														$full_img_url = cs_attachment_image_src($gal_list, 0, 0);
														?>
														<article class="col-md-4">
															<figure>
																<a href="<?php echo esc_url($full_img_url); ?>" rel="prettyPhoto"><img src="<?php echo esc_url($img_url); ?>" alt="<?php echo cs_get_post_img_title($post->ID); ?>"></a>
																<figcaption><a href="<?php echo esc_url($full_img_url); ?>" rel="prettyPhoto"><i class="icon-angle-right"></i></a></figcaption>
															</figure>
														</article>
														<?php
														}
														?>
													</div>
													<?php
													}
												}
												?>
                                                <div class="cs-spreater">
                                                    <div class="cs-divider-style"></div>
                                                </div>
                                                <?php
												// Pagination
												cs_portfolios_next_prev();
												if( $cs_portfolio_other == 'on' ) { 
												
													if( $cs_portfolio_other_title <> '' ) { ?>
													<div class="cs-heading">
														<h5><?php echo esc_attr( $cs_portfolio_other_title ); ?></h5>
													</div>
													<?php } ?>
													
													<div style="margin-bottom:0;" class="cs-portfolio cs-portfolio-plain light-box">
														<?php cs_port_others( true, '3' ) ?>
													</div>
												<?php
												}
												?>
                                            </div>
											<?php cs_port_banner( $cs_portfolio_btm_baner, 'bottom' ); ?>
                                        </div>
                                        <?php
									}
									else if( $cs_portfolio_style == 'style-3' ) {
										?>
                                        <div class="cs-project-details cs-details-list">
                                        	<div class="col-md-12">
                                                <div class="cs-heading">
                                                    <h1><?php the_title() ?></h1>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                            	<?php
												if( $cs_port_gallery == 'on' && $cs_port_list_gallery <> '' ) {
													
												if( ! is_array($cs_port_list_gallery) ) {
													$cs_port_list_gallery = explode(',', $cs_port_list_gallery);
												}
		
												if( is_array($cs_port_list_gallery) && sizeof($cs_port_list_gallery) > 0 ) {
													?>
													<ul class="cs-gallery-list">
                                                    	<?php
														foreach( $cs_port_list_gallery as $gal_list ) {
														
														$img_url = cs_attachment_image_src($gal_list, 696, 392);
														?>
														<li><img alt="<?php echo cs_get_post_img_title($post->ID); ?>" src="<?php echo esc_url($img_url); ?>"></li>
                                                        <?php
														}
														?>
													</ul>
													<?php
													}
												}
												?>
                                                <div class="cs-editor-text">
													<?php the_content(); ?>
                                                </div>
                                                <?php 
												$cs_portf_specs = array(
													'cs_portfolio_specs'			=> $cs_portfolio_specs,
													'cs_portfolio_specs_title'		=> $cs_portfolio_specs_title,
													'cs_portfolio_specs_desc'		=> $cs_portfolio_specs_desc,
													'cs_portfolio_specs_list'		=> $cs_portfolio_specs_list,
												);
												cs_port_specs( $cs_portf_specs );
												
												// Pagination
												cs_portfolios_next_prev();
												?>
                                            </div>
                                            <div class="col-md-3">
                                                <?php
                                                $cs_side_detail = array(
                                                    'cs_portfolio_date'			=> $cs_portfolio_date,
                                                    'cs_portfolio_client'		=> $cs_portfolio_client,
                                                    'cs_portfolio_team'			=> $cs_portfolio_team,
                                                    'cs_portfolio_location'		=> $cs_portfolio_location,
                                                    'cs_post_social_sharing'	=> $cs_post_social_sharing,
													'cs_widget_title'			=> true,
                                                );
                                                cs_port_side_detail( $cs_side_detail );
												if( $cs_portfolio_other == 'on' ) { 
												
												if( $cs_portfolio_other_title <> '' ) {
												?>
                                                <div class="widget-section-title">
                                                    <h5><?php echo esc_attr( $cs_portfolio_other_title ); ?></h5>
                                                </div>
                                                <?php
												}
												?>
                                                <ul class="cs-project-list">
                                                    <?php cs_port_others_side( '3' ) ?>
                                                </ul>
                                                <?php
												}
												?>
                                            </div>
                                            <?php cs_port_banner( $cs_portfolio_btm_baner, 'bottom' ); ?>
                                        </div>
                                        <?php
									}
								if( $cs_portfolio_style == 'style-1' ) {
								?>
                                </div>
                                <?php
								}
								?>
                            </div>
						</div>
					</div>
				</div>
			</div>
            <?php 
			if( $cs_portfolio_other == 'on' && $cs_portfolio_style == 'style-1' ) { 
			cs_owl_carousel();
			$cs_bg_img = $cs_portfolio_proj_bg <> '' ? 'background:url('.esc_url($cs_portfolio_proj_bg).') no-repeat; ' : '';
			?>
            <script type="text/javascript">
			var $ = jQuery;
			$(document).ready(function() {
				$(".cs-related-projects .cs-portfolio-<?php echo absint($cs_uniq) ?>").owlCarousel({
					margin: 10,
					autoPlay: 3000, //Set AutoPlay to 3 seconds
					nav: true,
					navText: [
						"<i class=' icon-arrow-left9'></i>",
						"<i class=' icon-arrow-right9'></i>"
					],	
					responsive:{
						0:{
							items:1,
							nav:true
						},
						600:{
							items:2,
							nav:false
						},
						1000:{
							items:3,
							nav:true,
							loop:false
						}
					}
				});
			});
			</script>
            <div style="<?php echo cs_allow_special_char($cs_bg_img) ?>background-size:cover;" class="page-section">
				<div class="container">
					<div class="row">
						<div class="section-fullwidth">
                            <div class="cs-related-projects cs-details2">
                                <?php if( $cs_portfolio_other_title <> '' ) { ?>
                                <div class="col-md-12">
                                    <div class="cs-detail-head">
                                        <h2><?php echo esc_attr( $cs_portfolio_other_title ); ?></h2>
                                    </div>
                                </div>
                                <?php } ?>
                                <div class="col-md-12">
                                    <div class="cs-portfolio cs-portfolio-plain cs-portfolio-<?php echo absint($cs_uniq) ?> light-box">
                                    	<?php cs_port_others() ?>
                                    </div>
                                </div>
                            </div>
						</div>
					</div>
				</div>
			</div>
			<?php
			}
		endwhile;
	endif;
	get_footer(); ?>           