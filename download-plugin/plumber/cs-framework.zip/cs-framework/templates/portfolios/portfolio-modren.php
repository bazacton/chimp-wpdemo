<?php
global $post,$wpdb,$cs_theme_options,$cs_counter_node,$column_attributes,$cs_portfolio_description,$cs_portfolio_excerpt;
extract($wp_query->query_vars);
$width = '314';
$height = '236';
$title_limit = 3;

$query = new WP_Query($args);
$post_count = $query->post_count;
if ($query->have_posts()) {
	$postCounter = 0;
	while ($query->have_posts()) : $query->the_post();
		$cs_port_list_gallery = get_post_meta($post->ID, 'cs_port_list_gallery', true);
		if( $cs_port_list_gallery <> '' ) {
			$cs_port_list_gallery = explode(',', $cs_port_list_gallery);
		
			if( is_array($cs_port_list_gallery) && sizeof($cs_port_list_gallery) > 0 ) {
				$img_url = cs_attachment_image_src($cs_port_list_gallery[0], $width, $height);
			}
		}
		$cs_postObject = get_post_meta($post->ID, "cs_full_data", true);
		
		$port_cats = get_the_terms( $post->ID, 'portfolio-category' );
		$cat_slug = '';
		foreach( $port_cats as $cat ) {
			$cat_slug .= ' '.$cat->slug;
		}
		?> 
		<li class="portfolio-item <?php echo cs_allow_special_char($cat_slug); ?> col-md-4">
			<div class="item-main">
                <article>
                    <div class="cs-portfolio-holder">
                        <div class="cs-media">
                            <figure><a href="<?php esc_url(the_permalink()); ?>"><img alt="<?php echo cs_get_post_img_title($post->ID); ?>" src="<?php echo esc_url($img_url); ?>"></a>
                                <figcaption>
                                    <div class="hover">
                                        <h4><a href="<?php esc_url(the_permalink()); ?>"><?php echo wp_trim_words(get_the_title($post->ID), $title_limit, '...'); ?></a></h4>
                                    </div>
                                    <section class="cs-text">
                                        <h4><a href="<?php esc_url(the_permalink()); ?>"><?php echo wp_trim_words(get_the_title($post->ID), ($title_limit-1), '...'); ?></a></h4>
                                        <span class="separator"></span>
                                        <?php
										$categories_list = get_the_term_list(get_the_id(), 'portfolio-category', '<span>', ', ', '</span>');
										if ($categories_list) {
											
											echo cs_allow_special_char( $categories_list );
										}
										?>
                                    </section>
                                </figcaption>
                            </figure>
                        </div>
                    </div>
                </article>
            </div>
		</li>
		<?php
	endwhile;
} else {
	_e('No Portfolio found.', 'cs_frame');
}
