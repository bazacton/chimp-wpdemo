<?php
/**
 * The template for displaying single Team
 */
	global $post, $cs_theme_options;
	$cs_uniq = rand(11111111, 99999999);
	$cs_teamObject = get_post_meta($post->ID, 'cs_full_data', true);
	
	$cs_team_position = get_post_meta($post->ID, 'cs_team_position', true);
	$cs_team_phone = get_post_meta($post->ID, 'cs_team_phone', true);
	$cs_team_email = get_post_meta($post->ID, 'cs_team_email', true);
	$cs_team_facebook = get_post_meta($post->ID, 'cs_team_facebook', true);
	$cs_team_twitter = get_post_meta($post->ID, 'cs_team_twitter', true);
	$cs_team_google = get_post_meta($post->ID, 'cs_team_google', true);
	$cs_team_linkedin = get_post_meta($post->ID, 'cs_team_linkedin', true);
	$cs_team_specs = get_post_meta($post->ID, 'cs_team_specs', true);
	$cs_team_specs_title = get_post_meta($post->ID, 'cs_team_specs_title', true);
	$cs_team_specs_subtitle = get_post_meta($post->ID, 'cs_team_specs_subtitle', true);
	$cs_team_specs_desc = get_post_meta($post->ID, 'cs_team_specs_desc', true);
	$cs_team_specs_list = get_post_meta($post->ID, 'cs_team_specs_list', true);
	$cs_team_exp = get_post_meta($post->ID, 'cs_team_exp', true);
	$cs_team_exp_title = get_post_meta($post->ID, 'cs_team_exp_title', true);
	$cs_team_exp_desc = get_post_meta($post->ID, 'cs_team_exp_desc', true);
	$cs_team_exp_list = get_post_meta($post->ID, 'cs_team_exp_list', true);
	$cs_team_partners = get_post_meta($post->ID, 'cs_team_partners', true);
	$cs_team_partners_title = get_post_meta($post->ID, 'cs_team_partners_title', true);
	$cs_team_list_gallery = get_post_meta($post->ID, 'cs_team_list_gallery', true);

	get_header();

	$width  = 350;
	$height = 350;
	
	if (have_posts()):
		while (have_posts()) : the_post();
			$image_url = cs_get_post_img_src($post->ID, $width, $height);
			?>
            <div style="background-color: #f7f7f7; padding: 30px 0px 0px 0px; margin: -40px 0px 30px 0px;" class="page-section">
                <div class="container">
                    <div class="row">
                        <div class="page-content-fullwidth">
                            <div class="cs-teamdetail col-md-12">
                            	<?php if( $image_url <> '' ) { ?>
                                <figure><a><img alt="<?php echo cs_get_post_img_title($post->ID); ?>" src="<?php echo esc_url( $image_url ); ?>"></a></figure>
                                <?php } ?>
                                <div class="cs-info-indetail">
                                    <h2><?php esc_attr( the_title() ); ?></h2>
									<?php if(  $cs_team_position <> '' ) { ?>
                                    <span><?php echo esc_attr( $cs_team_position ); ?></span>
                                    <?php } ?>
                                    <div class="cs-teaminfo">
                                        <p><?php the_content(); ?> 
                                        <ul class="cs-userinfo">
                                        	<?php if(  $cs_team_phone <> '' ) { ?>
                                            <li><i class="icon-phone6"></i> <?php echo esc_attr( $cs_team_phone ); ?></li>
                                            <?php
											}
											if(  $cs_team_email <> '' ) {
											?>
                                            <li><i class="icon-envelope4"></i> <?php echo sanitize_email( $cs_team_email ); ?></li>
                                            <?php } ?>
                                        </ul>
                                        <?php if(  $cs_team_email <> '' ) { ?>
                                        <a class="cs-teambtn cs-bgcolor" href="mailto:<?php echo sanitize_email( $cs_team_email ); ?>"><?php _e('Send Email', 'cs_frame'); ?></a>
                                        <?php
										}
										if(  $cs_team_facebook <> '' || $cs_team_twitter <> '' || $cs_team_google <> '' || $cs_team_linkedin <> '' ) {
										?>
                                        <div class="social-media">
                                            <ul>
                                                <li><a href="<?php echo esc_url( $cs_team_facebook ); ?>"><i class="icon-facebook9"></i></a></li>
                                                <li><a data-original-title="Twitter" href="<?php echo esc_url( $cs_team_twitter ); ?>"><i class="icon-twitter2"></i></a></li>
                                                <li><a data-original-title="Googleplus" href="<?php echo esc_url( $cs_team_google ); ?>"><i class="icon-googleplus7"></i></a></li>
                                                <li><a data-original-title="Linkedin" href="<?php echo esc_url( $cs_team_linkedin ); ?>"><i class="icon-linkedin4"></i></a></li>
                                            </ul>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php if( $cs_team_specs == 'on' || $cs_team_exp == 'on' ) { ?>
            <div style="background-color: #ffffff;" class="page-section">
				<div class="container">
					<div class="row">
						<div class="page-content-fullwidth">
                            <div class="cs-teamdetail">
                            	<?php if( $cs_team_specs == 'on' ) { ?>
                                <div class="element-size-50">
                                    <div class="col-md-12">
                                    	<?php if( $cs_team_specs_title <> '' ) { ?>
                                        <div class="cs-section-title">
                                            <h2><?php echo esc_attr($cs_team_specs_title); ?></h2>
                                        </div>
                                        <?php
										}
										if( $cs_team_specs_subtitle <> '' ) {
										?>
                                        <h5><?php echo esc_attr($cs_team_specs_subtitle); ?></h5>
                                        <?php
										}
										if( $cs_team_specs_desc <> '' ) {
										$cs_team_specs_desc = nl2br($cs_team_specs_desc);
										$cs_team_specs_desc = str_replace('<br />', '</p><p>', $cs_team_specs_desc);
										
										echo '<p>'.cs_allow_special_char($cs_team_specs_desc).'</p>';
										}
										
										if( $cs_team_specs_list <> '' ) {
										?>
                                        <div class="liststyle">
                                            <ul class="cs-iconlist">
                                            	<li>
                                                <i class="icon-arrow-circle-right"></i>
                                                <?php
												$cs_team_specs_list = nl2br($cs_team_specs_list);
												$cs_team_specs_list = str_replace('<br />', '</li><li><i class="icon-arrow-circle-right"></i>', $cs_team_specs_desc);
												echo cs_allow_special_char($cs_team_specs_list);
												?>
                                                </li>
                                            </ul>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php
								}
								if( $cs_team_exp == 'on' ) {
								?>
                                <div class="element-size-50">
                                    <div class="col-md-12">
                                        <?php if( $cs_team_exp_title <> '' ) { ?>
                                        <div class="cs-section-title">
                                            <h2><?php echo esc_attr($cs_team_exp_title); ?></h2>
                                        </div>
                                        <?php
										}
										if( $cs_team_exp_desc <> '' ) {
										$cs_team_exp_desc = nl2br($cs_team_exp_desc);
										$cs_team_exp_desc = str_replace('<br />', '</p><p>', $cs_team_exp_desc);
										
										echo '<p>'.cs_allow_special_char($cs_team_exp_desc).'</p>';
										}
										
										if( $cs_team_exp_list <> '' ) {
										?>
                                        <div class="liststyle">
                                            <ul class="cs-iconlist">
                                            	<li>
                                                <i class="icon-arrow-circle-right"></i>
                                                <?php
												$cs_team_exp_list = nl2br($cs_team_exp_list);
												$cs_team_exp_list = str_replace('<br />', '</li><li><i class="icon-arrow-circle-right"></i>', $cs_team_exp_list);
												echo cs_allow_special_char($cs_team_exp_list);
												?>
                                                </li>
                                            </ul>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>
						</div>
					</div>
				</div>
			</div>
            <?php 
			}
			if( $cs_team_partners == 'on' ) { 
			?>
            <div style=" padding:20px 0 ;" class="page-section">
				<div class="container">
					<div class="row">
						<div class="section-fullwidth">
							<div class="element-size-100">
                            	<?php if( $cs_team_partners_title <> '' ) {  ?>
								<div class="cs-section-title col-md-12">
						        	<h2><?php echo esc_attr($cs_team_partners_title); ?></h2>
						        </div>
                                <?php
                                }
								if( $cs_team_list_gallery <> '' ) {
									$cs_team_list_gallery = explode(',', $cs_team_list_gallery);
								
									if( is_array($cs_team_list_gallery) && sizeof($cs_team_list_gallery) > 0 ) {
									?>
									<div class="col-md-12">
										<div class="cs-partner no-clients-border">
											<ul class="row">
                                            	<?php
                                                foreach( $cs_team_list_gallery as $team_gal ) {
													$gal_url = cs_attachment_image_src($team_gal, 0, 0);
													if( $gal_url <> '' ) {
													?> 
													<li class="col-md-3"><figure><a><img src="<?php echo esc_url($gal_url); ?>"
                                                     alt="<?php echo cs_get_post_img_title($post->ID); ?>"></a></figure></li>
													<?php
													}
												}
												?>
											</ul>
										</div>
									</div>
									<?php
									}
								}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
			}
		endwhile;
	endif;
	
	get_footer();
	          