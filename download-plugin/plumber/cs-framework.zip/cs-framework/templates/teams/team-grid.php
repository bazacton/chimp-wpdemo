<?php
global $post,$wpdb,$cs_theme_options,$cs_counter_node,$column_attributes,$cs_team_post_description,$cs_team_post_excerpt;
extract($wp_query->query_vars);
$width = '350';
$height = '350';
$title_limit = 1000;
?>   
<div class="col-md-12">
    <div class="cs-team cs-teamgrid">
        <div class="row">
        <?php
        $query = new WP_Query($args);
        $post_count = $query->post_count;
        if ($query->have_posts()) {
            $postCounter = 0;
            while ($query->have_posts()) : $query->the_post();
                $thumbnail = cs_get_post_img_src($post->ID, $width, $height);
                $cs_postObject = get_post_meta($post->ID, "cs_full_data", true);
				
				$cs_team_position = get_post_meta($post->ID, 'cs_team_position', true);
				$cs_team_email = get_post_meta($post->ID, 'cs_team_email', true);
				$cs_team_facebook = get_post_meta($post->ID, 'cs_team_facebook', true);
				$cs_team_twitter = get_post_meta($post->ID, 'cs_team_twitter', true);
				$cs_team_google = get_post_meta($post->ID, 'cs_team_google', true);
				$cs_team_linkedin = get_post_meta($post->ID, 'cs_team_linkedin', true);
                ?> 
                <article class="col-md-4">
                    <div class="cs-wrapteam">
                    	<?php if( $thumbnail <> '' ) { ?>
                        <figure>
                            <a href="<?php esc_url(the_permalink()); ?>"><img alt="<?php echo cs_get_post_img_title($post->ID); ?>" src="<?php echo esc_url($thumbnail); ?>"></a>
                            <figcaption><a href="<?php esc_url(the_permalink()); ?>"><i class="icon-angle-right"></i></a></figcaption>
                        </figure>
                        <?php } ?>
                        <div class="text">
                        	<?php if( $cs_team_position <> '' ) { ?>
                            <span><?php echo esc_attr( $cs_team_position ); ?></span>
                            <?php } ?>
                            <h3><a href="<?php esc_url(the_permalink()); ?>"><?php echo wp_trim_words(get_the_title($post->ID), $title_limit, '...'); ?></a></h3>
                            <div class="cs-teaminfo">
                            	<?php if( $cs_team_email <> '' ) { ?>
                                <a class="cs-teambtn" href="mailto:<?php echo sanitize_email( $cs_team_email ); ?>"><?php _e('Send Email', 'cs_frame'); ?></a>
                                <?php
								}
								if(  $cs_team_facebook <> '' || $cs_team_twitter <> '' || $cs_team_google <> '' || $cs_team_linkedin <> '' ) {
								?>
								<div class="social-media">
									<ul>
										<li><a href="<?php echo esc_url( $cs_team_facebook ); ?>"><i class="icon-facebook9"></i></a></li>
										<li><a data-original-title="Twitter" href="<?php echo esc_url( $cs_team_twitter ); ?>"><i class="icon-twitter2"></i></a></li>
										<li><a data-original-title="Googleplus" href="<?php echo esc_url( $cs_team_google ); ?>"><i class="icon-googleplus7"></i></a></li>
										<li><a data-original-title="Linkedin" href="<?php echo esc_url( $cs_team_linkedin ); ?>"><i class="icon-linkedin4"></i></a></li>
									</ul>
								</div>
								<?php } ?>
                            </div>
                        </div>
                    </div>
                </article>
                <?php
            endwhile;
        } else {
            _e('No team found.','cs_frame');
        }
        ?>
        </div>
    </div>
</div>