<?php
/**
 * @Manage Columns
 * @return
 *
 */
 
if (!class_exists('post_type_team')) {

    class post_type_team {

        // The Constructor
        public function __construct() {
            // Adding columns
            add_filter('manage_teams_posts_columns', array(&$this, 'cs_teams_columns_add'));
            add_action('manage_teams_posts_custom_column', array(&$this, 'cs_teams_columns'), 10, 2);
			add_action('init', array(&$this, 'cs_teams_register'));
        }

		function cs_teams_columns_add($columns) {
			
			return $columns;
		}

		function cs_teams_columns($name) {
			global $post;
			switch ($name) {
				
			}
		}

		/**
		 * @Register Post Type
		 * @return
		 *
		 */
		function cs_teams_register() {
			$labels = array(
				'name' =>__('Teams','cs_frame'),
				'all_items' =>__('Teams','cs_frame'),
				'add_new_item' =>__('Add New Team','cs_frame'), 
				'edit_item' =>__('Edit Team','cs_frame'), 
				'new_item' =>__('New Team Item','cs_frame'),
				'add_new' =>__('Add New Team','cs_frame'),
				'view_item' =>__('View Team Item','cs_frame'), 
				'search_items' =>__('Search Team','cs_frame'), 
				'not_found' =>__('Nothing found','cs_frame'),  
				'not_found_in_trash' =>__('Nothing found in Trash','cs_frame'),
				'parent_item_colon' => ''
			);
			
			$args = array(
				'labels' => $labels,
				'public' => true,
				'publicly_queryable' => true,
				'show_ui' => true,
				'query_var' => true,
				'menu_icon' => 'dashicons-book',
				'rewrite' => true,
				'capability_type' => 'post',
				'has_archive' => true,
				'map_meta_cap' => true,
				'hierarchical' => false,
				'menu_position' => null,
				'can_export' => true,
				'supports' => array('title','editor','thumbnail')
			); 
			register_post_type( 'teams' , $args );

		}
	}
	
	return new post_type_team();
}
