<?php
/**
 * @Manage Columns
 * @return
 *
 */
 
if (!class_exists('post_type_portfolio')) {

    class post_type_portfolio {

        // The Constructor
        public function __construct() {
            // Adding columns
            add_filter('manage_portfolios_posts_columns', array(&$this, 'cs_portfolios_columns_add'));
            add_action('manage_portfolios_posts_custom_column', array(&$this, 'cs_portfolios_columns'), 10, 2);
			add_action('init', array(&$this, 'cs_portfolios_register'));
			add_action('init', array(&$this, 'cs_port_cat_register'));
        }
		
		function cs_portfolios_columns_add($columns) {
			$columns['category'] =__('Categories','cs_frame');
			return $columns;
		}

		function cs_portfolios_columns($name) {
			global $post;
			switch ($name) {
				case 'category':
					$categories = get_the_terms( $post->ID, 'portfolio-category' );
						if($categories <> ""){
							$couter_comma = 0;
							foreach ( $categories as $category ) {
								echo esc_attr($category->name);
								$couter_comma++;
								if ( $couter_comma < count($categories) ) {
									echo ", ";
								}
							}
						}
					break;
			}
		}
		
		
		/**
		 * @Register Post Type
		 * @return
		 *
		 */
		function cs_portfolios_register() {
			$labels = array(
				'name' =>__('Portfolios','cs_frame'),
				'all_items' =>__('Portfolios','cs_frame'),
				'add_new_item' =>__('Add New Portfolio','cs_frame'), 
				'edit_item' =>__('Edit Portfolio','cs_frame'), 
				'new_item' =>__('New Portfolio Item','cs_frame'),
				'add_new' =>__('Add New Portfolio','cs_frame'),
				'view_item' =>__('View Portfolio Item','cs_frame'), 
				'search_items' =>__('Search Portfolio','cs_frame'), 
				'not_found' =>__('Nothing found','cs_frame'),  
				'not_found_in_trash' =>__('Nothing found in Trash','cs_frame'),
				'parent_item_colon' => ''
			);
			
			$args = array(
				'labels' => $labels,
				'public' => true,
				'publicly_queryable' => true,
				'show_ui' => true,
				'query_var' => true,
				'menu_icon' => 'dashicons-book',
				'rewrite' => true,
				'capability_type' => 'post',
				'has_archive' => true,
				'map_meta_cap' => true,
				'hierarchical' => false,
				'menu_position' => null,
				'can_export' => true,
				'supports' => array('title','editor')
			); 
			register_post_type( 'portfolios' , $args );
		}
		
		/**
		 * @Register Categories
		 * @return
		 *
		 */	
		function cs_port_cat_register() {
			$labels = array(
				'name' =>__('Portfolio Categories','cs_frame'), 
				'search_items' =>__('Search Portfolio Categories','cs_frame'), 
				'edit_item' =>__('Edit Portfolio Category','cs_frame'), 
				'update_item' =>__('Update Portfolio Category','cs_frame'), 
				'add_new_item' =>__('Add New Category','cs_frame'), 
				'menu_name' =>__('Categories','cs_frame'), 
			); 	
			register_taxonomy('portfolio-category',array('portfolios'), array(
				'hierarchical' => true,
				'labels' => $labels,
				'show_ui' => true,
				'query_var' => true,
				'rewrite' => array('slug' => 'portfolio-category'),
			));
		}
	}
	
	return new post_type_portfolio();
}