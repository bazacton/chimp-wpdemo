<?php
/**
 * @Add Meta Box For Portfolios
 * @return
 *
 */
if (!class_exists('cs_portfolio_meta')) {

    class cs_portfolio_meta {

        public function __construct() {
            add_action('add_meta_boxes', array($this, 'cs_meta_portfolio_add'));
        }

        function cs_meta_portfolio_add() {
            add_meta_box('cs_meta_portfolio', __('Portfolio Options', 'cs_frame'), array($this, 'cs_meta_portfolio'), 'portfolios', 'normal', 'high');
        }

        function cs_meta_portfolio($post) {
            global $post, $cs_theme_options, $page_option, $cs_form_meta;
            //$cs_theme_options = get_option('cs_theme_options');
            $cs_builtin_seo_fields = isset($cs_theme_options['cs_builtin_seo_fields']) ? $cs_theme_options['cs_builtin_seo_fields'] : '';
            $cs_header_position = isset($cs_theme_options['cs_header_position']) ? $cs_theme_options['cs_header_position'] : '';

            cs_framework::cs_enqueue_timepicker_script();
            ?>		
            <div class="page-wrap page-opts left" style="overflow:hidden; position:relative; height: 1432px;">
                <div class="option-sec" style="margin-bottom:0;">
                    <div class="opt-conts">
                        <div class="elementhidden">
                            <nav class="admin-navigtion">
                                <ul id="cs-options-tab">
                                    <li><a href="javascript:;" name="#tab-general-settings"><i class="icon-cog3"></i><?php _e('General', 'cs_frame'); ?></a></li>
                                    <?php
                                    if (function_exists('cs_subheader_element')) {
                                        ?>
                                        <li><a href="javascript:;" name="#tab-subheader-options"><i class="icon-indent"></i> <?php _e('Sub Header', 'cs_frame'); ?> </a></li>
                                        <?php
                                    }
                                    if (function_exists('cs_header_postition_element') && function_exists('cs_seo_settitngs_element')) {
                                        if ($cs_header_position == 'absolute') {
                                            ?>
                                            <li><a href="javascript:;" name="#tab-header-position-settings"><i class="icon-forward"></i><?php _e('Header Absolute', 'cs_frame'); ?></a></li>
                                        <?php } ?>
                                        <?php if ($cs_builtin_seo_fields == 'on') { ?>
                                            <li><a href="javascript:;" name="#tab-seo-advance-settings"><i class="icon-dribbble"></i> <?php _e('Seo Options', 'cs_frame'); ?></a></li>
                                            <?php
                                        }
                                    }
                                    ?>
                                    <li><a href="javascript:;" name="#tab-portfolios-settings-cs-portfolios"><i class="icon-briefcase"></i><?php _e('Portfolio Options', 'cs_frame'); ?></a></li>
                                </ul>
                            </nav>
                            <div id="tabbed-content">
                                <div id="tab-general-settings">
                                    <?php $this->cs_portfolio_general_settings(); ?>
                                </div>
                                <?php
                                if (function_exists('cs_subheader_element')) {
                                    ?>
                                    <div id="tab-subheader-options">
                                        <?php cs_subheader_element(); ?>
                                    </div>
                                    <?php
                                }
                                if (function_exists('cs_header_postition_element') && function_exists('cs_seo_settitngs_element')) {
                                    if ($cs_header_position == 'absolute') {
                                        ?>
                                        <div id="tab-header-position-settings">
                                            <?php cs_header_postition_element(); ?>
                                        </div>
                                    <?php } ?>
                                    <?php if ($cs_builtin_seo_fields == 'on') { ?>
                                        <div id="tab-seo-advance-settings">
                                            <?php cs_seo_settitngs_element(); ?>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                                <div id="tab-portfolios-settings-cs-portfolios">
                                    <?php $this->cs_post_portfolio_fields(); ?>
                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
            <?php
        }

        /**
         * @Portfolios General Settings Function
         * @return
         *
         */
        function cs_portfolio_general_settings() {
            global $cs_xmlObject, $post, $cs_form_meta;
            $cs_form_meta->cs_form_checkbox_render(
                    array('name' => __('Social Sharing', 'cs_frame'),
                        'id' => 'post_social_sharing',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                        'hint' => '',
                    )
            );
        }

        /**
         * @Portfolio Custom Fileds Function
         * @return
         *
         */
        function cs_post_portfolio_fields() {
            global $post, $cs_theme_options, $page_option, $cs_form_meta;

            $team_data = array();

            $cs_args = array('posts_per_page' => '-1', 'post_type' => 'teams', 'orderby' => 'ID', 'post_status' => 'publish', 'order' => 'DESC');
            $cust_query = get_posts($cs_args);
            foreach ($cust_query as $cs_team) {
                $team_data[$cs_team->ID] = get_the_title($cs_team->ID);
            }

            $side_banners = array();
            $btm_banners = array();
            if (isset($cs_theme_options['banner_field_title']) && is_array($cs_theme_options['banner_field_title']) && sizeof($cs_theme_options['banner_field_title']) > 0) {
                $baner_i = 0;
                foreach ($cs_theme_options['banner_field_title'] as $banner) {
                    if ($cs_theme_options['banner_field_style'][$baner_i] == 'sidebar_banner') {
                        $side_banners[$baner_i] = $cs_theme_options['banner_field_title'][$baner_i];
                    }
                    if ($cs_theme_options['banner_field_style'][$baner_i] == 'bottom_banner') {
                        $btm_banners[$baner_i] = $cs_theme_options['banner_field_title'][$baner_i];
                    }
                    $baner_i++;
                }
            }

            $cs_form_meta->cs_form_select_render(
                    array('name' => __('Detail Style', 'cs_frame'),
                        'id' => 'portfolio_style',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                        'hint' => '',
                        'options' => array('style-1' => __('Style 1', 'cs_frame'), 'style-2' => __('Style 2', 'cs_frame'), 'style-3' => __('Style 3', 'cs_frame'))
                    )
            );

            $cs_form_meta->cs_form_date_render(
                    array('name' => __('Portfolio Date', 'cs_frame'),
                        'id' => 'portfolio_date',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                        'hint' => ''
                    )
            );
            $cs_form_meta->cs_form_text_render(
                    array('name' => __('Portfolio Client', 'cs_frame'),
                        'id' => 'portfolio_client',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                        'hint' => ''
                    )
            );
            $cs_form_meta->cs_form_textarea_render(
                    array('name' => __('Portfolio Location', 'cs_frame'),
                        'id' => 'portfolio_location',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                        'hint' => ''
                    )
            );
            $cs_form_meta->cs_form_checkbox_with_field_render(
                    array('name' => __('Other Projects', 'cs_frame'),
                        'id' => 'portfolio_other',
                        'field_id' => 'portfolio_other_title',
                        'classes' => '',
                        'std' => '',
                        'field' => array('std' => 'on', 'field_std' => __('Other Projects', 'cs_frame')),
                        'description' => '',
                        'hint' => ''
                    )
            );
            $cs_form_meta->cs_media_url(
                    array('name' => __('Projects Background Image', 'cs_frame'),
                        'id' => 'portfolio_proj_bg',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                        'hint' => ''
                    )
            );

            if (sizeof($side_banners) > 0) {
                $cs_form_meta->cs_form_select_render(
                        array('name' => __('Side Banner', 'cs_frame'),
                            'id' => 'portfolio_side_baner',
                            'classes' => '',
                            'std' => '',
                            'description' => '',
                            'hint' => '',
                            'options' => $side_banners
                        )
                );
            }
            if (sizeof($btm_banners) > 0) {
                $cs_form_meta->cs_form_select_render(
                        array('name' => __('Bottom Banner', 'cs_frame'),
                            'id' => 'portfolio_btm_baner',
                            'classes' => '',
                            'std' => '',
                            'description' => '',
                            'hint' => '',
                            'options' => $btm_banners
                        )
                );
            }
            $cs_form_meta->cs_heading_render(
                    array('name' => __('Team', 'cs_frame'),
                        'id' => 'team_section',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                    )
            );
            $cs_form_meta->cs_form_multiselect_render(
                    array('name' => __('Portfolio Team', 'cs_frame'),
                        'id' => 'portfolio_team',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                        'hint' => '',
                        'options' => $team_data
                    )
            );

            $cs_form_meta->cs_heading_render(
                    array('name' => __('Specifications', 'cs_frame'),
                        'id' => 'spec_section',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                    )
            );
            $cs_form_meta->cs_form_checkbox_with_field_render(
                    array('name' => __('Specifications', 'cs_frame'),
                        'id' => 'portfolio_specs',
                        'field_id' => 'portfolio_specs_title',
                        'classes' => '',
                        'std' => '',
                        'field' => array('std' => 'on', 'field_std' => __('Project Specification', 'cs_frame')),
                        'description' => '',
                        'hint' => ''
                    )
            );
            $cs_form_meta->cs_form_textarea_render(
                    array('name' => __('Description', 'cs_frame'),
                        'id' => 'portfolio_specs_desc',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                        'hint' => ''
                    )
            );
            $cs_form_meta->cs_form_textarea_render(
                    array('name' => __('List', 'cs_frame'),
                        'id' => 'portfolio_specs_list',
                        'classes' => '',
                        'std' => '',
                        'description' => __('Press enter after entering a list item.', 'cs_frame'),
                        'hint' => ''
                    )
            );
            $cs_form_meta->cs_heading_render(
                    array('name' => __('Gallery', 'cs_frame'),
                        'id' => 'gallery_section',
                        'classes' => '',
                        'std' => '',
                        'description' => '',
                    )
            );
            $cs_form_meta->cs_form_checkbox_with_field_render(
                    array('name' => __('Gallery', 'cs_frame'),
                        'id' => 'port_gallery',
                        'field_id' => 'port_gallery_title',
                        'classes' => '',
                        'std' => '',
                        'field' => array('std' => 'on', 'field_std' => __('Gallery', 'cs_frame')),
                        'description' => '',
                        'hint' => ''
                    )
            );
            $cs_form_meta->cs_gallery_render(
                    array('name' => __('Add Gallery Images', 'cs_frame'),
                        'id' => 'port_list_gallery',
                        'classes' => '',
                        'std' => 'gallery_meta_form',
                    )
            );
        }

    }

    return new cs_portfolio_meta();
}
