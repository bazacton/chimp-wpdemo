<?php
/**
 * @Add Meta Box For Teams
 * @return
 *
 */

if( ! class_exists('cs_team_meta') ) {
	class cs_team_meta {
		
		public function __construct(){
			add_action('add_meta_boxes', array($this, 'cs_meta_team_add'));
		}

		function cs_meta_team_add(){  
			add_meta_box( 'cs_meta_team',  __('Team Options','cs_frame'), array($this, 'cs_meta_team'), 'teams', 'normal', 'high' );  
		}
		
		function cs_meta_team( $post ) {
			global $post ,$cs_theme_options, $page_option,$cs_form_meta;
			//$cs_theme_options = get_option('cs_theme_options');
			$cs_builtin_seo_fields  = isset( $cs_theme_options['cs_builtin_seo_fields'] ) ? $cs_theme_options['cs_builtin_seo_fields'] : ''; 
			$cs_header_position 	= isset( $cs_theme_options['cs_header_position'] ) ? $cs_theme_options['cs_header_position'] : '';
					
			?>		
			<div class="page-wrap page-opts left" style="overflow:hidden; position:relative; height: 1432px;">
				<div class="option-sec" style="margin-bottom:0;">
					<div class="opt-conts">
						<div class="elementhidden">
							<nav class="admin-navigtion">
							  <ul id="cs-options-tab">
                              	<?php
								if( function_exists('cs_subheader_element') ) {
								?>
								<li><a href="javascript:;" name="#tab-subheader-options"><i class="icon-indent"></i> <?php _e('Sub Header','cs_frame');?> </a></li>
								<?php 
								}
								if( function_exists('cs_header_postition_element') && function_exists('cs_seo_settitngs_element') ) {
									if($cs_header_position == 'absolute'){?>
										<li><a href="javascript:;" name="#tab-header-position-settings"><i class="icon-forward"></i><?php _e('Header Absolute','cs_frame');?></a></li>
									<?php }?>
									<?php if($cs_builtin_seo_fields == 'on'){?>
									<li><a href="javascript:;" name="#tab-seo-advance-settings"><i class="icon-dribbble"></i> <?php _e('Seo Options','cs_frame');?></a></li>
									<?php }
								}
								?>
								<li><a href="javascript:;" name="#tab-teams-settings-cs-teams"><i class="icon-briefcase"></i><?php _e('Team Options','cs_frame'); ?></a></li>
							</ul>
							</nav>
							<div id="tabbed-content">
                            	<?php
								if( function_exists('cs_subheader_element') ) {
								?>
								<div id="tab-subheader-options">
									<?php cs_subheader_element();?>
								</div>
								<?php 
								}
								if( function_exists('cs_header_postition_element') && function_exists('cs_seo_settitngs_element') ) {
									if($cs_header_position == 'absolute'){?>
									 <div id="tab-header-position-settings">
										 <?php cs_header_postition_element();?>
									</div>
									<?php } ?>
									<?php if($cs_builtin_seo_fields == 'on'){?>
									<div id="tab-seo-advance-settings">
										<?php cs_seo_settitngs_element();?>
									</div>
									<?php }
								}
								?>
								<div id="tab-teams-settings-cs-teams">
									<?php $this->cs_post_team_fields(); ?>
								</div>
							</div>  
						</div>
					</div>
				</div>
			</div>
			<div class="clear"></div>
		<?php
        }
				
		/**
		 * @Team Custom Fileds Function
		 * @return
		 *
		 */
		function cs_post_team_fields(){
			global $post ,$cs_theme_options, $page_option,$cs_form_meta;	
			
			$cs_form_meta->cs_form_text_render(
				array(  'name'	=> __('Position','cs_frame'),
						'id'	=> 'team_position',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_form_text_render(
				array(  'name'	=> __('Phone','cs_frame'),
						'id'	=> 'team_phone',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_form_text_render(
				array(  'name'	=> __('Email','cs_frame'),
						'id'	=> 'team_email',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_form_text_render(
				array(  'name'	=> __('Facebook','cs_frame'),
						'id'	=> 'team_facebook',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_form_text_render(
				array(  'name'	=> __('Twitter','cs_frame'),
						'id'	=> 'team_twitter',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_form_text_render(
				array(  'name'	=> __('Google Plus','cs_frame'),
						'id'	=> 'team_google',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_form_text_render(
				array(  'name'	=> __('Linkedin','cs_frame'),
						'id'	=> 'team_linkedin',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_heading_render(
				array(  'name'	=> __('Job Specifications','cs_frame'),
						'id'	=> 'job_section',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
					)
			);
			$cs_form_meta->cs_form_checkbox_with_field_render(
				array(  'name'	=> __('Job Specifications','cs_frame'),
						'id'	=> 'team_specs',
						'field_id'	=> 'team_specs_title',
						'classes' => '',
						'std'	=> '',
						'field'	=> array('std' => 'on', 'field_std' => __('Job Specification','cs_frame')),
						'description'  => '',
						'hint'  => ''
					)
			);	
			$cs_form_meta->cs_form_text_render(
				array(  'name'	=> __('Sub Title','cs_frame'),
						'id'	=> 'team_specs_subtitle',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_form_textarea_render(
				array(  'name'	=> __('Description','cs_frame'),
						'id'	=> 'team_specs_desc',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_form_textarea_render(
				array(  'name'	=> __('List','cs_frame'),
						'id'	=> 'team_specs_list',
						'classes' => '',
						'std'	=> '',
						'description'  => __('Press enter after entering a list item','cs_frame'),
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_heading_render(
				array(  'name'	=> __('Experience and Expertise','cs_frame'),
						'id'	=> 'expertise_section',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
					)
			);
			$cs_form_meta->cs_form_checkbox_with_field_render(
				array(  'name'	=> __('Experience and Expertise','cs_frame'),
						'id'	=> 'team_exp',
						'field_id'	=> 'team_exp_title',
						'classes' => '',
						'std'	=> '',
						'field'	=> array('std' => 'on', 'field_std' => __('Experience and Expertise','cs_frame')),
						'description'  => '',
						'hint'  => ''
					)
			);	
			$cs_form_meta->cs_form_textarea_render(
				array(  'name'	=> __('Description','cs_frame'),
						'id'	=> 'team_exp_desc',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_form_textarea_render(
				array(  'name'	=> __('List','cs_frame'),
						'id'	=> 'team_exp_list',
						'classes' => '',
						'std'	=> '',
						'description'  => __('Press enter after entering a list item','cs_frame'),
						'hint'  => ''
					)
			);
			
			$cs_form_meta->cs_heading_render(
				array(  'name'	=> __('Partners','cs_frame'),
						'id'	=> 'partners_section',
						'classes' => '',
						'std'	=> '',
						'description'  => '',
					)
			);
			$cs_form_meta->cs_form_checkbox_with_field_render(
				array(  'name'	=> __('Partners','cs_frame'),
						'id'	=> 'team_partners',
						'field_id'	=> 'team_partners_title',
						'classes' => '',
						'std'	=> '',
						'field'	=> array('std' => 'on', 'field_std' => __('Partners','cs_frame')),
						'description'  => '',
						'hint'  => ''
					)
			);
			$cs_form_meta->cs_gallery_render(
				array(  'name'		=> __('Add Gallery Images','cs_frame'),
						'id'		=> 'team_list_gallery',
						'classes'   => '',
						'std'		=> 'gallery_meta_form',
					)
			);
			
		}
	}
	
	return new cs_team_meta();
}
