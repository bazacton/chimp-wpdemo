<?php
/**
 * Plugin Name: cs framework
 * Plugin URI: http://themeforest.net/user/Chimpstudio/
 * Description: Lawyer cs framework
 * Version: 1.0
 * Author: ChimpStudio
 * Author URI: http://themeforest.net/user/Chimpstudio/
 * @package WP Lawyer
 * Text Domain: framework
 */

// Direct access not allowed.
if (!defined('ABSPATH')) {
    exit;
}


class cs_framework
{

    public $admin_notices;

    /**
     * construct function.
     */
    public function __construct()
    {
        // Define constants
        define('FRAMEWORK_CORE_DIR', WP_PLUGIN_DIR . '/cs-framework');
        define('FRAMEWORK_LANGUAGES_DIR', FRAMEWORK_CORE_DIR . '/languages');
        $this->admin_notices = array();

        add_action('display_tweets_shortcode', array(&$this, 'display_tweets_shortcode_callback'));
        //admin notices
        add_action('admin_notices', array($this, 'framework_notices_callback'));
        // Initialize plugin
        add_action('init', array($this, 'init'), 1);
    }

    /**
     * Initialize application, load text domain, enqueue scripts, include classes and add actions
     */
    public function init()
    {
        // Add Plugin textdomain
        $locale = apply_filters('plugin_locale', get_locale(), 'framework');
        load_textdomain('framework', FRAMEWORK_LANGUAGES_DIR . '/cs-framework' . "-" . $locale . '.mo');
        load_plugin_textdomain('framework', false, FRAMEWORK_LANGUAGES_DIR);

        /*Required files for front end*/
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }


    /**
     * Admin notification
     */
    public function framework_notices_callback()
    {
        if (isset($this->admin_notices) && !empty($this->admin_notices)) {
            foreach ($this->admin_notices as $value) {
                echo $value;
            }
        }
    }

}

new cs_framework();


/*----- cs framework -----*/

/* add action widget register */
if (!function_exists('cs_widget_register')) {
    function cs_widget_register($name)
    {
        add_action('widgets_init', function () use ($name) {
            return register_widget($name);
        });
    }
}

/* add action widget unregister */
if (!function_exists('cs_widget_unregister')) {
    function cs_widget_unregister($name)
    {
        add_action('widgets_init', function () use ($name) {
            return unregister_widget($name);
        });
    }
}

/* add action for meta boxes */
if (!function_exists('cs_meta_boxes')) {
    function cs_meta_boxes($name)
    {
        add_action('add_meta_boxes', $name);
    }
}

/* add meta boxe */
if (!function_exists('cs_meta_box')) {
    function cs_meta_box($id, $title, $callback, $screen = null, $context = 'advanced', $priority = 'default', $callback_args = null)
    {
        add_meta_box($id, __($title, 'framework'), $callback, $screen, $context, $priority, $callback_args);
    }
}

/* send mail */
if (!function_exists('cs_mail')) {
    function cs_mail($to, $subject, $message, $headers = '', $attachments = array())
    {
        return wp_mail($to, $subject, $message, $headers, $attachments);
    }
}

/* base 64 encode */
if (!function_exists('base_64_encode')) {
    function base_64_encode($string = '')
    {
        return base64_encode($string);
    }
}

/* base 64 decode */
if (!function_exists('base_64_decode')) {
    function base_64_decode($string = '')
    {
        return base64_decode($string);
    }
}

/* register taxonomy */
if (!function_exists('cs_register_taxonomy')) {
    function cs_register_taxonomy($taxonomy, $object_type, $args)
    {
        register_taxonomy($taxonomy, $object_type, $args);
    }
}

/* register post type */
if (!function_exists('cs_register_post_type')) {
    function cs_register_post_type($post_type, $args = array())
    {
        register_post_type($post_type, $args);
    }
}

/* initialize CURL issue resolve */
if (!function_exists('cs_curl')) {
    function cs_curl()
    {
        $ci = curl_init();
        return $ci;
    }
}

/* Execute CURL issue resolve */
if (!function_exists('cs_curl_exec')) {
    function cs_curl_exec($ci)
    {
        $response = curl_exec($ci);
        return $response;
    }
}

/* Execute CURL CLOSE issue resolve */
if (!function_exists('cs_curl_close')) {
    function cs_curl_close($ci)
    {
        curl_close($ci);
    }
}

/* add short code */
if (!function_exists('cs_shortcode_add')) {
    function cs_shortcode_add($tag, $callback)
    {
        add_shortcode($tag, $callback);
    }
}

/* deregister script */
if (!function_exists('cs_wp_der_script')) {
    function cs_wp_der_script($var)
    {
        wp_deregister_script($var);
    }
}

/* return $_SERVER  */
if (!function_exists('cs_glob_server')) {
    function cs_glob_server($var)
    {
        if ($var != '') {
            return isset($_SERVER[$var]) ? $_SERVER[$var] : false;
        } else {
            return $_SERVER;
        }

    }
}

/* Remove filter */
if (!function_exists('cs_remove_filters')) {
    function cs_remove_filters($tag, $function_to_remove, $priority = 10, $accepted_args = 1)
    {
        remove_filter($tag, $function_to_remove, $priority = 10, $accepted_args = 1);
    }
}

/* force balance tags */
if (!function_exists('complete_tag_forcely')) {
    function complete_tag_forcely($text)
    {
        return force_balance_tags($text);
    }
}

/* force balance tags */
if (!function_exists('tag_complete')) {
    function tag_complete($text, $force = false)
    {
        return balanceTags($text, $force = false);
    }
}

/* force balance tags */
if (!function_exists('is_active_plugin')) {
    function is_active_plugin($plugin)
    {
        return is_plugin_active($plugin);
    }
}

/* file open */
if (!function_exists('framework_fileopen')) {
    function framework_fileopen($file, $mode)
    {
        $file_path = explode('/', $file);
        $get_file_name = end($file_path);
        $get_extention = explode('.', $get_file_name);
        $extention_of_file = end($get_extention);
        $ext_files = array('jpg', 'jpeg', 'png', 'svg');
        if (!in_array($extention_of_file, $ext_files)) {
            return fopen($file, $mode);
        }
        return;
    }
}

/* file end of */
if (!function_exists('framework_file_endof')) {
    function framework_file_endof($file)
    {
        return feof($file);
    }
}

/* file gets */
if (!function_exists('framework_file_gets')) {
    function framework_file_gets($file, $len)
    {
        return fgets($file, $len);
    }
}

/* file close */
if (!function_exists('framework_file_close')) {
    function framework_file_close($file)
    {
        return fclose($file);
    }
}

/* file close */
if (!function_exists('global_server')) {
    function global_server($value = '')
    {
        if ($value != '') {
            return $_SERVER[$value];
        } else {
            return $_SERVER;
        }
    }
}

/* iframe  */
if (!function_exists('html_i_frame')) {
    function html_i_frame($align = '', $frameborder = '', $height = '', $longdesc = '', $marginheight = '', $marginwidth = '', $name = '', $sandbox = '', $scrolling = '', $src = '', $srcdoc = '', $width = '', $extra_attr = '')
    {
        return '<iframe 
        align="' . $align . '" 
        frameborder="' . $frameborder . '" 
        height="' . $height . '" 
        longdesc="' . $longdesc . '" 
        marginheight="' . $marginheight . '" 
        marginwidth="' . $marginwidth . '" 
        name="' . $name . '" 
        sandbox="' . $sandbox . '" 
        scrolling="' . $scrolling . '" 
        src="' . $src . '" 
        srcdoc="' . $srcdoc . '" 
        width="' . $width . '" 
         ' . $extra_attr . ' 
        </iframe>';
    }
}