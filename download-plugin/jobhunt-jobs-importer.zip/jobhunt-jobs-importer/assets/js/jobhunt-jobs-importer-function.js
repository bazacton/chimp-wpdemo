jQuery(document).on('submit', '.jobhunt-import-jobs-xml-render', function (e) {
    e.stopPropagation();
    e.preventDefault();
    var form_data = new FormData(jQuery(".jobhunt-import-jobs-xml-render")[0]);
    form_data.append('action', 'jobs_import_xml_file_render');
    jQuery(".jobs-import-area").html('<div class="jobhunt-import-export-loader"><i class="item-status processing" style="width: 75px;height: 75px;"></i></div>');
    jQuery.ajax({
        type: "POST",
        url: jobhunt_globals.ajax_url,
        data: form_data,
        contentType: false,
        processData: false,
        success: function (response) {
            jQuery(".jobs-import-area").html(response);
        }
    });
});

jQuery(document).on('submit', '.jobhunt-import-jobs-submit-form', function (e) {
    e.stopPropagation();
    e.preventDefault();
    var form_data = new FormData(jQuery(".jobhunt-import-jobs-submit-form")[0]);
    form_data.append('action', 'jobs_import_form_submit');
    jQuery(".jobs-import-area").html('<div class="jobhunt-import-export-loader"><i class="item-status processing" style="width: 75px;height: 75px;"></i></div>');
    jQuery.ajax({
        type: "POST",
        url: jobhunt_globals.ajax_url,
        data: form_data,
        contentType: false,
        processData: false,
        success: function (response) {
            jQuery(".jobs-import-area").html(response);
        }
    });
});


jQuery(document).on('click', '.jobhunt-export-jobs', function (e) {
    e.stopPropagation();
    e.preventDefault();
    jQuery(".jobs-import-area").html('<div class="jobhunt-import-export-loader"><i class="item-status processing" style="width: 75px;height: 75px;"></i></div>');
    var form_data = new FormData();
    form_data.append('action', 'jobs_export_download');
    jQuery.ajax({
        type: "POST",
        url: jobhunt_globals.ajax_url,
        data: form_data,
        contentType: false,
        processData: false,
        success: function (response) {
            jQuery(".jobs-import-area").html(response);
        }
    });
});


jQuery(document).on('click', '.jobhunt-import-jobs-file', function (e) {
   jQuery("#jobs_import_file").click();
});

jQuery(document).on('change', '#jobs_import_file', function (e) {
   jQuery(".jobhunt-import-jobs-xml-render").submit();
});


